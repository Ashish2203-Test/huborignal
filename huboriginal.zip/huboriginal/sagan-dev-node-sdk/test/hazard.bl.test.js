/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var hazardBL = require('../business-logic/hazard.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "hazard.json");

describe('Hazard BL', function () {
    var docId = "";
    var entity = "hazard"; // This is due the bl._name that I don't like.
    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();

        dbmgr.create(entity, function (err) {
            expect(err).to.be.null;
            done();
        });
    });


    afterEach(function (done) {
        dbmgr.delete(entity, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            done();
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };

    describe('hazard.insert', function () {

        it('hazard.insert doc', function (done) {
            var docToInsert = require(dataFilePath).insertDoc[0].data[0];
            docToInsert.username = docId;

            hazardBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                hazardBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    expect(getDoc.username).to.be.equal(docId);
                    expect(getDoc.ishandled).to.be.true;
                    expect(getDoc.timestamp).not.to.be.null;
                    var hazardID = new Date(getDoc.timestamp).getTime() + "-" + getDoc.username;
                    expect(getDoc.hazardid).to.be.equal(hazardID);

                    done();
                });
            });
        });

        it('hazard.insert with timestamp', function (done) {
            var docToInsert = require(dataFilePath).insertDocWithTimeStamp[0].data[0];
            docToInsert.username = docId;

            hazardBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                hazardBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    expect(getDoc.username).to.be.equal(docId);
                    expect(getDoc.ishandled).to.be.true;
                    expect(getDoc.timestamp).not.to.be.null;
                    expect(getDoc.timestamp).to.be.equal(docToInsert.timestamp);
                    var hazardID = "-" + getDoc.username;
                    expect(getDoc.hazardid).to.contain(hazardID);

                    done();
                });
            });
        });

        it('hazard.insert isHandled undefined', function (done) {
            var docToInsert = require(dataFilePath).insertDocNoIsHandled[0].data[0];
            docToInsert.username = docId;

            hazardBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                hazardBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    expect(getDoc.username).to.be.equal(docId);
                    expect(getDoc.ishandled).to.be.false;
                    expect(getDoc.timestamp).not.to.be.null;
                    var hazardID = new Date(getDoc.timestamp).getTime() + "-" + getDoc.username;
                    expect(getDoc.hazardid).to.be.equal(hazardID);

                    done();
                });
            });
        });
    });

    describe('hazard.getByHazardID', function () {
        it('hazard.getByHazardID single doc', function (done) {
            var testName = "getByHazardIDSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                hazardBL.getByID(insertedDoc.id, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    hazardBL.getByHazardID(getResult.hazardid, function (err, getHazard) {
                        expect(err).to.be.null;
                        expect(getHazard).not.to.be.null;
                        expect(getHazard).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('hazard.getByHazardID multiple doc', function (done) {
            var testName = "getByHazardIDMultipleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                hazardBL.getAllByAttribute("username", "test1", function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult.length).to.be.equal(1);

                    hazardBL.getByHazardID(getResult[0].hazardid, function (err, getHazard) {
                        expect(err).to.be.null;
                        expect(getHazard).not.to.be.null;
                        expect(getHazard).to.be.deep.equal(getResult[0]);

                        done();
                    });
                });
            });
        });

        it('hazard.getByHazardID non existing doc', function (done) {
            var testName = "getByHazardIDNonExistingDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                hazardBL.getByHazardID("asdf", function (err, getHazard) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Got too many hazards or none')
                    expect(getHazard).to.be.null;

                    done();
                });
            });
        });
    });

    describe('hazard.getHazardEventsByShiftTimeStamp', function () {

        it('hazard.getHazardEventsByShiftTimeStamp single doc exact date', function (done) {
            var testName = "getHazardEventsByShiftTimeStampSingleDocExactDate";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);

                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp single doc date after', function (done) {
            var testName = "getHazardEventsByShiftTimeStampSingleDocDateAfter";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-13T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp single doc date before', function (done) {
            var testName = "getHazardEventsByShiftTimeStampSingleDocBeforeAfter";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp multiple docs', function (done) {
            var testName = "getHazardEventsByShiftTimeStampMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp multiple docs Different days', function (done) {
            var testName = "getHazardEventsByShiftTimeStampMultipleDocsDifferentDays";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp more than 40 docs', function (done) {
            var testName = "getHazardEventsByShiftTimeStampMoreThan40Docs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(40);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp username exists', function (done) {
            var testName = "getHazardEventsByShiftTimeStampUsernameExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, "test", function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp username does not exists', function (done) {
            var testName = "getHazardEventsByShiftTimeStampUsernameDoesNotExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, "test", function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp more than one user', function (done) {
            var testName = "getHazardEventsByShiftTimeStampMoreThanOneUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, "test", function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEventsByShiftTimeStamp sorting timestamps', function (done) {
            var testName = "getHazardEventsByShiftTimeStampSortingTimestamps";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2010-12-12T07:19:20.070Z";

                hazardBL.getHazardEventsByShiftTimeStamp(date, undefined, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;

                    var lastDate = results[0].timestamp;

                    results.forEach(function (hazard) {
                        expect(hazard.timestamp).not.to.be.null;
                        expect(lastDate).to.be.at.least(hazard.timestamp);
                        lastDate = hazard.timestamp;
                    });

                    done();
                });
            });
        });
    });

    describe('hazard.getUserHazardEvents', function () {

        it('hazard.getUserHazardEvents Single user singe doc', function (done) {
            var testName = "getUserHazardEventsSingleUserSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents Single user multiple doc', function (done) {
            var testName = "getUserHazardEventsSingleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);
                    expect(results[0].username).to.be.equal(username);
                    expect(results[1].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents Single user empty doc', function (done) {
            var testName = "getUserHazardEventsSingleUserEmptyDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents Single user no doc', function (done) {
            var testName = "getUserHazardEventsSingleUserNoDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents multiple user single doc', function (done) {
            var testName = "getUserHazardEventsMultipleUserSingleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents multiple user multiple doc', function (done) {
            var testName = "getUserHazardEventsMultipleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test1";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);
                    expect(results[0].username).to.be.equal(username);
                    expect(results[1].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents include docs', function (done) {
            var testName = "getUserHazardEventsIncludeDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getUserHazardEvents dont include docs', function (done) {
            var testName = "getUserHazardEventsDontIncludeDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getUserHazardEvents(username, false, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).not.to.exist;

                    done();
                });
            });
        });
    });

    describe('hazard.getMyHazardEventsByStatus', function () {

        it('hazard.getMyHazardEventsByStatus Single user singe doc', function (done) {
            var testName = "getMyHazardEventsByStatusSingleUserSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus Single user multiple doc', function (done) {
            var testName = "getMyHazardEventsByStatusSingleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);
                    expect(results[0].username).to.be.equal(username);
                    expect(results[1].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus Single user empty doc', function (done) {
            var testName = "getMyHazardEventsByStatusSingleUserEmptyDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus Single user no doc', function (done) {
            var testName = "getMyHazardEventsByStatusSingleUserNoDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus multiple user single doc', function (done) {
            var testName = "getMyHazardEventsByStatusMultipleUserSingleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus multiple user multiple doc', function (done) {
            var testName = "getMyHazardEventsByStatusMultipleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test1";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);
                    expect(results[0].username).to.be.equal(username);
                    expect(results[1].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus multiple user multiple doc', function (done) {
            var testName = "getMyHazardEventsByStatusMultipleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test1";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);
                    expect(results[0].username).to.be.equal(username);
                    expect(results[1].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus violated', function (done) {
            var testName = "getMyHazardEventsByStatusViolated";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, true, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });

        it('hazard.getMyHazardEventsByStatus not violated', function (done) {
            var testName = "getMyHazardEventsByStatusNotViolated";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.getMyHazardEventsByStatus(username, false, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].username).to.be.equal(username);

                    done();
                });
            });
        });
    });

    describe('hazard.getHazardEvents ', function () {

        it('hazard.getHazardEvents single doc exact date', function (done) {
            var testName = "getHazardEventsSingleDocExactDate";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 50, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);

                    done();
                });
            });
        });


        it('hazard.getHazardEvents single doc date after', function (done) {
            var testName = "getHazardEventsSingleDocDateAfter";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-13T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 50, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getHazardEvents single doc date before', function (done) {
            var testName = "getHazardEventsSingleDocBeforeAfter";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 50, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents multiple docs', function (done) {
            var testName = "getHazardEventsMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 50, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents multiple docs Different days', function (done) {
            var testName = "getHazardEventsMultipleDocsDifferentDays";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 50, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(2);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents more than 5 docs', function (done) {
            var testName = "getHazardEventsMoreThan5Docs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-11T07:19:20.070Z";

                hazardBL.getHazardEvents(date, undefined, undefined, 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(5);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents username exists', function (done) {
            var testName = "getHazardEventsUsernameExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";
                var username = "test";

                hazardBL.getHazardEvents(date, username, undefined, 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents username does not exists', function (done) {
            var testName = "getHazardEventsUsernameDoesNotExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";
                var username = "test";

                hazardBL.getHazardEvents(date, username, undefined, 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).to.be.empty;

                    done();
                });
            });
        });

        it('hazard.getHazardEvents more than one user', function (done) {
            var testName = "getHazardEventsMoreThanOneUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2016-12-12T07:19:20.070Z";
                var username = "test";

                hazardBL.getHazardEvents(date, username, undefined, 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);


                    done();
                });
            });
        });

        it('hazard.getHazardEvents sorting timestamps', function (done) {
            var testName = "getHazardEventsSortingTimestamps";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2010-12-12T07:19:20.070Z";
                var username = "test";

                hazardBL.getHazardEvents(date, username, undefined, 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;

                    var lastDate = results[0].timestamp;

                    results.forEach(function (hazard) {
                        expect(hazard.timestamp).not.to.be.null;
                        expect(lastDate).to.be.at.least(hazard.timestamp);
                        lastDate = hazard.timestamp;
                    });

                    done();
                });
            });
        });

        it('hazard.getHazardEvents shield uuid', function (done) {
            var testName = "getHazardEventsShieldUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var date = "2010-12-12T07:19:20.070Z";
                var username = "test";

                hazardBL.getHazardEvents(date, username, "1", 5, function (err, results) {
                    expect(err).to.be.null;
                    expect(results).not.to.be.null;
                    expect(results).not.to.be.empty;
                    expect(results.length).to.be.equal(1);
                    expect(results[0].shieldUUID).to.be.equal("1");

                    done();
                });
            });
        });
    });

    describe('hazard.updateHazardEventStatus', function () {

        it('hazard.updateHazardEventStatus existing field', function (done) {
            var testName = "updateHazardEventStatusExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventStatus(insertedDoc.id, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).to.be.false;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventStatus existing field same value', function (done) {
            var testName = "updateHazardEventStatusExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventStatus(insertedDoc.id, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).to.be.true;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventStatus adding field', function (done) {
            var testName = "updateHazardEventStatusAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventStatus(insertedDoc.id, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).to.be.false;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventStatus removing field', function (done) {
            var testName = "updateHazardEventStatusRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventStatus(insertedDoc.id, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventStatus missing id', function (done) {
            var testName = "updateHazardEventStatusMissingID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventStatus(undefined, true, function (err, result) {
                    expect(err).not.to.be.null;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).to.be.true;

                        done();
                    });
                });
            });
        });
    });

    describe('hazard.updateHazardEventValidationType', function () {

        it('hazard.updateHazardEventValidationType existing field', function (done) {
            var testName = "updateHazardEventValidationTypeExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventValidationType(insertedDoc.id, 'type2', function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.validationType).to.be.equal('type2');;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventValidationType existing field same value', function (done) {
            var testName = "updateHazardEventValidationTypeExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventValidationType(insertedDoc.id, 'type1', function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.validationType).to.be.equal('type1');;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventValidationType adding field', function (done) {
            var testName = "updateHazardEventValidationTypeAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventValidationType(insertedDoc.id, 'type2', function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.validationType).to.be.equal('type2');;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventValidationType removing field', function (done) {
            var testName = "updateHazardEventValidationTypeRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventValidationType(insertedDoc.id, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isviolated).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventValidationType missing id', function (done) {
            var testName = "updateHazardEventValidationTypeMissingID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventValidationType(undefined, 'type1', function (err, result) {
                    expect(err).not.to.be.null;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.validationType).to.be.equal('type1');;

                        done();
                    });
                });
            });
        });
    });

    describe('hazard.updateHazardEventHandledStatus', function () {

        it('hazard.updateHazardEventHandledStatus existing field', function (done) {
            var testName = "updateHazardEventHandledStatusExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventHandledStatus(insertedDoc.id, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.ishandled).to.be.false;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventHandledStatus existing field same value', function (done) {
            var testName = "updateHazardEventHandledStatusExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventHandledStatus(insertedDoc.id, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.ishandled).to.be.true;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventHandledStatus adding field', function (done) {
            var testName = "updateHazardEventHandledStatusAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventHandledStatus(insertedDoc.id, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    console.log("result: " + JSON.stringify(result));
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.ishandled).to.be.true;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventHandledStatus removing field', function (done) {
            var testName = "updateHazardEventHandledStatusRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventHandledStatus(insertedDoc.id, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.ishandled).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('hazard.updateHazardEventHandledStatus missing id', function (done) {
            var testName = "updateHazardEventHandledStatusMissingID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                hazardBL.updateHazardEventHandledStatus(undefined, true, function (err, result) {
                    expect(err).not.to.be.null;

                    hazardBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.ishandled).to.be.true;

                        done();
                    });
                });
            });
        });
    });

    describe('hazard.deleteAllByUsername', function () {

        it('hazard.deleteAllByUsername Single user singe doc', function (done) {
            var testName = "deleteAllByUsernameSingleUserSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).to.be.empty;
                        done();

                    });
                });
            });
        });

        it('hazard.deleteAllByUsername Single user multiple doc', function (done) {
            var testName = "deleteAllByUsernameSingleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).to.be.empty;
                        done();

                    });
                });
            });
        });

        it('hazard.deleteAllByUsername Single user empty doc', function (done) {
            var testName = "deleteAllByUsernameSingleUserEmptyDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).to.be.empty;

                var username = "test";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).to.be.empty;
                        done();

                    });
                });
            });
        });

        it('hazard.deleteAllByUsername Single user no doc', function (done) {
            var testName = "deleteAllByUsernameSingleUserNoDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).not.to.be.empty;
                        expect(all.length).to.be.equal(1);
                        done();

                    });
                });
            });
        });

        it('hazard.deleteAllByUsername Multiple user single doc', function (done) {
            var testName = "deleteAllByUsernameMultipleUserSingleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).not.to.be.empty;
                        expect(all.length).to.be.equal(1);
                        done();

                    });
                });
            });
        });

        it('hazard.deleteAllByUsername Multiple user multiple doc', function (done) {
            var testName = "deleteAllByUsernameMultipleUserMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "test1";

                hazardBL.deleteAllByUsername(username, function (err, deleteResult) {
                    expect(err).to.be.null;
                    expect(deleteResult).to.be.true;

                    hazardBL.getAll(function (err, all) {
                        expect(err).to.be.null;
                        expect(all).not.to.be.null;
                        expect(all).not.to.be.empty;
                        expect(all.length).to.be.equal(1);
                        done();

                    });
                });
            });
        });
    });

});

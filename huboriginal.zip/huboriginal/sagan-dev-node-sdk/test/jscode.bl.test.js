/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var jsCodeBL = require('../business-logic/jscode.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "jscode.json");

describe('JSCode BL', function () {
    var docId = "";
    var originalARGV = process.argv[1];

    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();

        dbmgr.create(jsCodeBL._name, function (err) {
            expect(err).to.be.null;
            done();
        });

    });


    afterEach(function (done) {
        dbmgr.delete(jsCodeBL._name, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;

            process.argv[1] = originalARGV;
            done();
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };

    describe('jscode.getCodeByName', function () {
        it('jscode.getCodeByName single doc', function (done) {
            var testName = "getCodeByNameSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var codeName = "name1";

                jsCodeBL.getCodeByName(codeName, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByName multiple docs same name', function (done) {
            var testName = "getCodeByNameMultipleDocsSameName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var codeName = "name1";

                jsCodeBL.getCodeByName(codeName, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getCodeByName multiple docs different name', function (done) {
            var testName = "getCodeByNameMultipleDocsDifferentName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var codeName = "name1";

                jsCodeBL.getCodeByName(codeName, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByName undefined name', function (done) {
            var testName = "getCodeByNameUndefinedName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCodeByName(undefined, function (err, code) {
                    expect(err).not.to.be.null;
                    expect(code).to.be.null;

                    done();
                });
            });
        });
    });

    describe('jscode.getCodeByShieldUUID', function () {
        it('jscode.getCodeByShieldUUID single doc', function (done) {
            var testName = "getCodeByShieldUUIDSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = "uuid1";

                jsCodeBL.getCodeByShieldUUID(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUID multiple docs same UUID', function (done) {
            var testName = "getCodeByShieldUUIDMultipleDocsSameUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = "uuid1";

                jsCodeBL.getCodeByShieldUUID(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUID multiple docs different UUID', function (done) {
            var testName = "getCodeByShieldUUIDMultipleDocsDifferentUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = "uuid1";

                jsCodeBL.getCodeByShieldUUID(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUID undefined UUID', function (done) {
            var testName = "getCodeByShieldUUIDUndefinedUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCodeByShieldUUID(undefined, function (err, code) {
                    expect(err).not.to.be.null;
                    expect(code).to.be.null;

                    done();
                });
            });
        });
    });

    describe('jscode.getCodeByShieldUUIDArray', function () {
        it('jscode.getCodeByShieldUUIDArray single doc', function (done) {
            var testName = "getCodeByShieldUUIDArraySingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = ["uuid1"];

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray single doc Not As Array', function (done) {
            var testName = "getCodeByShieldUUIDArraySingleDocNotAsArray";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = "uuid1";

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray multiple docs same UUID', function (done) {
            var testName = "getCodeByShieldUUIDArrayMultipleDocsSameUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = ["uuid1"];

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray multiple docs different UUID', function (done) {
            var testName = "getCodeByShieldUUIDArrayMultipleDocsDifferentUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = ["uuid1"];

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray multiple docs different UUID Array', function (done) {
            var testName = "getCodeByShieldUUIDArrayMultipleDocsDifferentUUIDArray";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = ["uuid1", "uuid2"];

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray undefined UUID', function (done) {
            var testName = "getCodeByShieldUUIDArrayUndefinedUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCodeByShieldUUIDArray(undefined, function (err, code) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Must specify array');
                    expect(code).to.be.null;

                    done();
                });
            });
        });

        it('jscode.getCodeByShieldUUIDArray Empty UUID', function (done) {
            var testName = "getCodeByShieldUUIDArrayEmptyUUID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var uuid = [];

                jsCodeBL.getCodeByShieldUUIDArray(uuid, function (err, code) {
                    expect(err).to.be.null;
                    expect(code).to.be.empty;

                    done();
                });
            });
        });
    });

    describe('jscode.getCommonCode', function () {
        it('jscode.getCommonCode single doc', function (done) {
            var testName = "getCommonCodeSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCommonCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('common1\n');

                    done();
                });
            });
        });

        it('jscode.getCommonCode multiple docs same name', function (done) {
            var testName = "getCommonCodeMultipleDocsSameName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCommonCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('common1');
                    expect(code).to.contain('common2');

                    done();
                });
            });
        });

        it('jscode.getCommonCode multiple docs different name', function (done) {
            var testName = "getCommonCodeMultipleDocsDifferentName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCommonCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('common\n');

                    done();
                });
            });
        });

        it('jscode.getCommonCode no common code', function (done) {
            var testName = "getCommonCodeNoCommonCode";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getCommonCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).to.be.empty;

                    done();
                });
            });
        });
    });

    describe('jscode.getAllCode  ', function () {
        it('jscode.getAllCode single doc', function (done) {
            var testName = "getAllCodeSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getAllCode multiple docs', function (done) {
            var testName = "getAllCodeMultipleDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getAllCode no docs', function (done) {
            var testName = "getAllCodeNoDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).to.be.empty;

                    done();
                });
            });
        });
    });

    describe('jscode.getAllCode (constructCode)', function () {
        it('jscode.getAllCode (jscode.constructCode) single doc', function (done) {
            var testName = "constructCodeSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('shield1\n');

                    done();
                });
            });
        });

        it('jscode.getAllCode multiple docs same name', function (done) {
            var testName = "constructCodeMultipleDocsSameName";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1');
                    expect(code).to.contain('shield2');

                    done();
                });
            });
        });

        it('jscode.getAllCode (jscode.constructCode) code structure', function (done) {
            var testName = "constructCodeStructure";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.contain('shield1\n');
                    expect(code).to.contain('shield2\n');

                    done();
                });
            });
        });

        it('jscode.getAllCode (jscode.constructCode) single doc common', function (done) {
            var testName = "constructCodeSingleDocCommon";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('common1\n');

                    done();
                });
            });
        });

        it('jscode.getAllCode (jscode.constructCode) single common single shield', function (done) {
            var testName = "constructCodeSingleCommonSingleShield";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllCode(function (err, code) {
                    expect(err).to.be.null;
                    expect(code).not.to.be.null;
                    expect(code).to.be.equal('common1\nshield1\n');

                    done();
                });
            });
        });
    });

    describe('jscode.updateJSCodeByID', function () {

        it('jscode.updateJSCodeByID existing field', function (done) {
            var testName = "updateJSCodeByIDExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                jsCodeBL.updateJSCodeByID(insertedDoc.id, "shield2", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    jsCodeBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.code).to.be.equal("shield2");

                        done();
                    });
                });
            });
        });

        it('jscode.updateJSCodeByID existing field same value', function (done) {
            var testName = "updateJSCodeByIDExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                jsCodeBL.updateJSCodeByID(insertedDoc.id, 'shield1', function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    jsCodeBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.code).to.be.equal("shield1");

                        done();
                    });
                });
            });
        });

        it('jscode.updateJSCodeByID adding field', function (done) {
            var testName = "updateJSCodeByIDAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                jsCodeBL.updateJSCodeByID(insertedDoc.id, "shield2", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    jsCodeBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.code).to.be.equal("shield2");

                        done();
                    });
                });
            });
        });

        it('jscode.updateJSCodeByID removing field', function (done) {
            var testName = "updateJSCodeByIDRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                jsCodeBL.updateJSCodeByID(insertedDoc.id, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    jsCodeBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.code).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('jscode.updateJSCodeByID missing id', function (done) {
            var testName = "updateJSCodeByIDMissingID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                jsCodeBL.updateJSCodeByID(undefined, "shield2", function (err, result) {
                    expect(err).not.to.be.null;

                    jsCodeBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.code).to.be.equal("shield1");

                        done();
                    });
                });
            });
        });
    });

    describe('jscode.updateOrCreateJSDocIfNeeded', function () {

        it('jscode.updateOrCreateJSDocIfNeeded doc does not exists', function (done) {
            var testName = "updateOrCreateJSDocIfNeededDocNotExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var name = "name1";
                var code = "code1";
                var shieldUUID = "uuid1";
                var type = "shield";

                jsCodeBL.updateOrCreateJSDocIfNeeded(name, shieldUUID, type, code, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;

                    jsCodeBL.getByID(result.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.shieldUUID).to.be.equal(shieldUUID);
                        expect(selectedDoc.code).to.be.equal(code);
                        expect(selectedDoc.type).to.be.equal(type);
                        expect(selectedDoc.name).to.be.equal(name);

                        done();
                    });
                });
            });
        });

        it('jscode.updateOrCreateJSDocIfNeeded doc exists', function (done) {
            var testName = "updateOrCreateJSDocIfNeededDocExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var name = "name1";
                var code = "code2";
                var shieldUUID = "uuid1";
                var type = "shield";

                jsCodeBL.updateOrCreateJSDocIfNeeded(name, shieldUUID, type, code, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;

                    jsCodeBL.getByID(result.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.shieldUUID).to.be.equal(shieldUUID);
                        expect(selectedDoc.code).to.be.equal(code);
                        expect(selectedDoc.type).to.be.equal(type);
                        expect(selectedDoc.name).to.be.equal(name);

                        done();
                    });
                });
            });
        });

        it('jscode.updateOrCreateJSDocIfNeeded too many docs', function (done) {
            var testName = "updateOrCreateJSDocIfNeededTooManyDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var name = "name1";
                var code = "code2";
                var shieldUUID = "uuid1";
                var type = "shield";

                jsCodeBL.updateOrCreateJSDocIfNeeded(name, shieldUUID, type, code, function (err, result) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal("Too many JSCode documents with the name " + name);
                    expect(result).to.be.null;

                    done();
                });
            });
        });
    });

    describe('jscode.updateShieldDefinitionsFromFiles', function () {

        it('jscode.updateShieldDefinitionsFromFiles folder does not exist', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "updateShieldDefinitionsFromFiles", "folderDoesNotExist", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).not.to.be.null;
                expect(result).to.be.null;

                done();
            });
        });

        it('jscode.updateShieldDefinitionsFromFiles no files with extension .js', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "updateShieldDefinitionsFromFiles", "noJsFiles", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).not.to.be.null;
                expect(err).to.be.equal("No js files");
                expect(result).to.be.null;

                done();
            });
        });

        it('jscode.updateShieldDefinitionsFromFiles single file with extension .js', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "updateShieldDefinitionsFromFiles", "singleFile", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("shield");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.updateShieldDefinitionsFromFiles multiple files with extension .js', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "updateShieldDefinitionsFromFiles", "multipleFiles", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var calls = [];

                calls.push(function (asyncCallback) {
                    jsCodeBL.getAllByAttribute("name", "oneShield", function (err, docs) {
                        expect(err).to.be.null;

                        var fileDoc = docs[0];
                        expect(fileDoc).not.to.be.null;
                        expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                        expect(fileDoc.type).to.be.equal("shield");
                        expect(fileDoc.code).not.to.be.null;

                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    jsCodeBL.getAllByAttribute("name", "twoShield", function (err, docs) {
                        expect(err).to.be.null;

                        var fileDoc = docs[0];
                        expect(fileDoc).not.to.be.null;
                        expect(fileDoc.shieldUUID).to.be.equal("uuid2");
                        expect(fileDoc.type).to.be.equal("shield");
                        expect(fileDoc.code).not.to.be.null;

                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    jsCodeBL.getAll(function (err, docs) {
                        expect(err).to.be.null;

                        expect(docs).not.to.be.null;
                        expect(docs).not.to.be.empty;
                        expect(docs.length).to.be.equal(2);

                        asyncCallback(null, true);
                    });
                });
                async.parallel(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('jscode.updateShieldDefinitionsFromFiles multiple files with varoius extensions', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "updateShieldDefinitionsFromFiles", "multipleFilesWithNoJsFiles", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var calls = [];

                calls.push(function (asyncCallback) {
                    jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                        expect(err).to.be.null;

                        var fileDoc = docs[0];
                        expect(fileDoc).not.to.be.null;
                        expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                        expect(fileDoc.type).to.be.equal("shield");
                        expect(fileDoc.code).not.to.be.null;

                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    jsCodeBL.getAll(function (err, docs) {
                        expect(err).to.be.null;

                        expect(docs).not.to.be.null;
                        expect(docs).not.to.be.empty;
                        expect(docs.length).to.be.equal(1);

                        asyncCallback(null, true);
                    });
                });
                async.parallel(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });
    });

    describe('jscode.extractShieldUUIDFromCode', function () {

        it('jscode.extractShieldUUIDFromCode shield uuid exists', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldUUIDFromCode", "shieldUUIDexists", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("shield");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldUUIDFromCode shield uuid does not exist', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldUUIDFromCode", "shieldsUUIDDoesNotExist", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.empty;
                    expect(fileDoc.type).to.be.equal("shield");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldUUIDFromCode double lines of shield uuid', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldUUIDFromCode", "shieldUUIDDoubleLine", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("shield");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });
    });

    describe('jscode.extractShieldTypeFromName', function () {

        it('jscode.extractShieldTypeFromName file name is shield', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldTypeFromName", "shield", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someShield", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("shield");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldTypeFromName file name is common', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldTypeFromName", "common", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "somecommon", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("common");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldTypeFromName file name is safelet', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldTypeFromName", "safelet", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "someSafelet", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("safelet");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldTypeFromName file name is PreProcessing', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldTypeFromName", "preProcessing", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "somePreProcessing", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.equal("PreProcessing");
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });

        it('jscode.extractShieldTypeFromName file name has no name', function (done) {
            // mocking the path
            process.argv[1] = path.join(__dirname, "bl", "jscode", "extractShieldTypeFromName", "nothing", "void");

            jsCodeBL.updateShieldDefinitionsFromFiles(function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                jsCodeBL.getAllByAttribute("name", "some", function (err, docs) {
                    expect(err).to.be.null;

                    var fileDoc = docs[0];
                    expect(fileDoc).not.to.be.null;
                    expect(fileDoc.shieldUUID).to.be.equal("uuid1");
                    expect(fileDoc.type).to.be.empty;
                    expect(fileDoc.code).not.to.be.null;

                    done();
                });
            });
        });
    });
});
/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var tools = {};
var exec_async = require('async');
var credentials = require('../credentials.js').getCredentialsByServiceName('cloudantNoSQLDB');
var cloudant = require('cloudant');
var cloudantDB = cloudant({
    url: credentials.url,
    plugin: 'retry'
});

var log = console.log;

tools.disableLogs = function () {
    console.log = function () {
    };
};

tools.enableLogs = function () {
    console.log = log;
};

function clearDB(db, callback) {
    return function (callback) {
        cloudantDB.db.destroy(db, function (err, result) {
            if (err)
                console.log(err);
            else {
                console.log("Deleted db - " + db);
            }
        });

    };
}

tools.clearDBs = function (callback) {
    var dbPrefix = (process.env.WF_DB_NAME_PREFIX) ? process.env.WF_DB_NAME_PREFIX + "-test" : "test";
    cloudantDB.db.list(function (err, body) {
            // body is an array
            var async_tasks = [];
            body.forEach(function (db) {
                if (db.startsWith(dbPrefix)) {
                    async_tasks.push(clearDB(db));
                }
            });
            exec_async.parallel(async_tasks, function () {
                setTimeout(callback(), 100);
            });
        }
    )
    ;
};

var view = {
    "_id": "_design/shields",
    "views": {
        "testIDView": {
            "map": "function(doc) {\n  emit(doc.testID, 1);\n}"
        }
    }
};

tools.getViewWithDocID = function(docID) {
    view._id = "_design/" + docID;
    return (view);
};

tools.removeIdAndRev = function(docs) {
    docs.forEach(function(doc) {
        delete doc._rev;
        delete doc._id;
    });

    return docs;
};

module.exports = tools;
/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var shieldBL = require('../business-logic/shield.bl.js');
var shieldAssociationBL = require('../business-logic/shieldassociation.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "shield.json");

describe('Shield BL', function () {
    var docId = "";

    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();

        dbmgr.create(shieldBL._name, function (err) {
            expect(err).to.be.null;
            dbmgr.create(shieldAssociationBL._name, function (err) {
                expect(err).to.be.null;
                done();
            });
        });
    });


    afterEach(function (done) {
        dbmgr.delete(shieldBL._name, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            dbmgr.delete(shieldAssociationBL._name, function (err) {
                testTools.enableLogs();
                expect(err).to.be.null;
                done();
            });
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };

    describe('shield.getShieldByUUID', function () {

        it('shield.getShieldByUUID one shield single doc', function (done) {
            var testName = "getShieldByUUIDOneShieldSingleDoc";
            var shieldUUID = "uuid1";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldByUUID(shieldUUID, function (err, selectedShield) {
                    expect(err).to.be.null;
                    expect(selectedShield).not.to.be.null;
                    expect(selectedShield).not.to.be.empty;
                    expect(selectedShield.UUID).to.be.equal(shieldUUID);
                    expect(selectedShield.name).to.be.equal("shield1");

                    done();
                });
            });
        });

        it('shield.getShieldByUUID multiple shield single doc', function (done) {
            var testName = "getShieldByUUIDMultipleShieldsSingleDoc";
            var shieldUUID = "uuid2";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldByUUID(shieldUUID, function (err, selectedShield) {
                    expect(err).to.be.null;
                    expect(selectedShield).not.to.be.null;
                    expect(selectedShield).not.to.be.empty;
                    expect(selectedShield.UUID).to.be.equal(shieldUUID);
                    expect(selectedShield.name).to.be.equal("shield2");

                    done();
                });
            });
        });

        // Race condition of which doc is inserted first (and the test is inconclusive);
        // it('shield.getShieldByUUID multiple shield multiple doc', function (done) {
        //     var testName = "getShieldByUUIDMultipleShieldsMultipleDoc";
        //     var shieldUUID = "uuid1";
        //     loadTestByName(testName, function (err, result) {
        //
        //         expect(err).to.be.null;
        //         expect(result).not.to.be.null;
        //
        //         shieldBL.getShieldByUUID(shieldUUID, function (err, selectedShield) {
        //             expect(err).to.be.null;
        //             expect(selectedShield).not.to.be.null;
        //             expect(selectedShield).not.to.be.empty;
        //             expect(selectedShield.UUID).to.be.equal(shieldUUID);
        //             expect(selectedShield.name).to.be.equal("shield1");
        //
        //             done();
        //         });
        //     });
        // });

        it('shield.getShieldByUUID no such UUID (no docs)', function (done) {
            var testName = "getShieldByUUIDNonExistingUUID";
            var shieldUUID = "uuid3";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldByUUID(shieldUUID, function (err, selectedShield) {
                    expect(err).to.be.null;
                    expect(selectedShield).to.be.undefined;

                    done();
                });
            });
        });

        it('shield.getShieldByUUID UUID is missing (undefined)', function (done) {
            var testName = "getShieldByUUIDUndefinedUUID";
            var shieldUUID;
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldByUUID(shieldUUID, function (err, selectedShield) {
                    expect(err).not.to.be.null;
                    expect(selectedShield).to.be.undefined;

                    done();
                });
            });
        });
    });

    describe('shield.getShieldsByUser', function () {

        it('shield.getShieldsByUser single shield single association', function (done) {

            var testName = "getShieldsByUserSingleShieldSingleAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).not.to.be.empty;
                    expect(userShields).to.be.a('array');
                    expect(userShields.length).to.be.equal(1);

                    expect(userShields[0].UUID).to.be.equal("uuid1");

                    done();
                });
            });
        });

        it('shield.getShieldsByUser single shield no association', function (done) {

            var testName = "getShieldsByUserSingleShieldNoAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).to.be.empty;
                    expect(userShields).to.be.a('array');

                    done();
                });
            });
        });

        it('shield.getShieldsByUser single shield non existing association', function (done) {

            var testName = "getShieldsByUserSingleShieldNonExistingAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).to.be.empty;
                    expect(userShields).to.be.a('array');

                    done();
                });
            });
        });

        it('shield.getShieldsByUser multiple shield single association', function (done) {

            var testName = "getShieldsByUserMultipleShieldSingleAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).not.to.be.empty;
                    expect(userShields).to.be.a('array');
                    expect(userShields.length).to.be.equal(1);

                    expect(userShields[0].UUID).to.be.equal("uuid1");

                    done();
                });
            });
        });

        it('shield.getShieldsByUser multiple shield multiple association', function (done) {

            var testName = "getShieldsByUserMultipleShieldMultipleAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).not.to.be.empty;
                    expect(userShields).to.be.a('array');
                    expect(userShields.length).to.be.equal(2);

                    var uuid1 = userShields.find(function findElement(element) {
                        return element.UUID === "uuid1";
                    });

                    expect(uuid1).not.to.be.null;

                    var uuid2 = userShields.find(function findElement(element) {
                        return element.UUID === "uuid2";
                    });

                    expect(uuid2).not.to.be.null;

                    done();
                });
            });
        });

        it('shield.getShieldsByUser single shield non existing association', function (done) {

            var testName = "getShieldsByUserNoShieldSingleAssociation";
            var username = "test";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).to.be.empty;
                    expect(userShields).to.be.a('array');

                    done();
                });
            });
        });

        it('shield.getShieldsByUser multiple shield single association', function (done) {

            var testName = "getShieldsByUserMultipleUsersSingleShieldSingleAssociation";
            var username = "test1";

            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldBL.getShieldsByUser(username, function (err, userShields) {
                    expect(err).to.be.null;
                    expect(userShields).not.to.be.null;
                    expect(userShields).not.to.be.empty;
                    expect(userShields).to.be.a('array');
                    expect(userShields.length).to.be.equal(1);

                    expect(userShields[0].UUID).to.be.equal("uuid1");

                    done();
                });
            });
        });
    });
});


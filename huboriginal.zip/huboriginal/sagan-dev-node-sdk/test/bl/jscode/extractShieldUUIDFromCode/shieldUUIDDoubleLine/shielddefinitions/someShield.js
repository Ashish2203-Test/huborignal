/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

SHIELD_UUID = uuid1;
SHIELD_UUID = uuid2;
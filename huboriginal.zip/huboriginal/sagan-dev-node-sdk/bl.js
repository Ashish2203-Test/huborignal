/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var fs = require('fs');
var config = require('./config.js');
var wfconfig = config.loadRootConfigFile();
var path = require('path');

// script that loads all the bls
var bl = {};

var wfbldir = path.join(__dirname, "/business-logic/");

bl.loadbls = function() {
    // console.log(" WF DIR " + wfbldir);
    // console.log(" WF DIR 1" + path.resolve(wfbldir));
    registerbls(wfbldir);

    if (wfconfig.businesslogic && wfconfig.businesslogic.path) {
        var otherDirs = wfconfig.businesslogic.path;

        otherDirs.forEach(function(dir) {
            var targetPath = path.resolve(dir);
            registerbls(targetPath);
        });
    }
};

var registerbls = function(bldir) {
    var dirExists = fs.existsSync(bldir);
    if (!dirExists) {
        console.log("WARNING " +
            "module = BL, " +
            "function = registerbls, " +
            "message = Could not find path" + bldir);
    } else {
        files = fs.readdirSync(bldir);

        files.forEach(function(fileName) {
            //var entityName = fileName.substring(0, fileName.indexOf(".", 0));
            var entityName = fileName.substring(0, fileName.indexOf(".", 0));
            if (!bl[entityName]) {
                bl[entityName] = require(path.join(bldir, fileName));
                console.log("INFO " +
                    "module = BL, " +
                    "function = registerbls, " +
                    "fileName = " + fileName + ", " +
                    "path = " + bldir + ", " +
                    "message = " + "Loaded");
            } else {
                mergeEntities(bl[entityName], require(path.join(bldir, fileName)));
                console.log("INFO " +
                    "module = BL, " +
                    "function = registerbls, " +
                    "fileName = " + fileName + ", " +
                    "path = " + bldir + ", " +
                    "message = " + "Merged");
            }
        });
    }
};


var mergeEntities = function(target, source) {
    keys = Object.keys(source);

    keys.forEach(function(key) {
        target[key] = source[key];
    });
};

module.exports = bl;

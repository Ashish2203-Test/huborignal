/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var framework = require('./index.js');
var se = framework.shieldEngine;
se.startServer();

var iotf = framework.iotfClient;

var sendPayload = function(payload) {
    console.log("asdasdfasfdsasdf");
    iotf.publishPayload(payload, "dean", "dean", "dean");
};

var payload = { se: [ '16', '2', '8', '5', '15', '9', '4' ],
    ts: '2016-12-26T08:26:20.149Z',
    dt: 'MSBand',
    hr: { bpm: 66 },
    usr: 'user1',
    uuid: 'F444',
    threshold: undefined,
    location:
        { spd: 0,
            hA: 10,
            course: -1,
            alt: 81.97381591796875,
            lon: 35.10837508368782,
            vA: 12,
            lat: 32.69719469829714 },
    timestamp: '2016-12-26T08:26:20.149Z',
    shieldsEnabled: [ '16', '2', '8', '5', '15', '9', '4' ],
    deviceType: 'MSBand',
    username: 'otvemp' }

setTimeout(sendPayload, 5000, payload);

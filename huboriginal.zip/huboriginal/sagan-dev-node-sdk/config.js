/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var exec = require('child_process').exec;
var execsync = require('child_process').execSync;
var path = require('path');
var fs = require('fs');

var config = {};

//////////////////////////////////////////
/////     Config Runtime Deployement /////
//////////////////////////////////////////

config.rootDir = path.dirname(process.argv[1]) + "/";

config.workingOnLocalDeveloperLaptop = process.env.WF_DEPLOY_TARGET === "local";
config.localPorts = process.env.WF_DEPLOY_PORTS === "true";

////////////////////////////////////
/////     Config File Reader   /////
////////////////////////////////////

config.loadRootConfigFile = function () {
    if (validateConfigurationPath()) {
        var configFilePath = process.env.WF_CONFIG_FILE_PATH;
        var configFile = require(configFilePath);

        mandatoryRootEnvs(configFile);

        console.log("INFO, " +
            "module = config, " +
            "function = loadRootConfigFile, " +
            "configfile = " + configFilePath + ", " +
            "msg = configuration file loaded ");
        return configFile;
    } else {
        console.log("ERROR, " +
            "module = config, " +
            "function = loadRootConfigFile, " +
            "msg = Missing configuration file");
        return {};
        //process.exit(1);
    }
};


function validateConfigurationPath() {
    var configFilePath = process.env.WF_CONFIG_FILE_PATH;

    // First, let user defined configuration be used, override root config file.
    if (process.env.WF_CONFIG_FILE_PATH) {
        configFilePath = path.resolve(configFilePath);
        process.env.WF_CONFIG_FILE_PATH = configFilePath;
        if (fs.existsSync(configFilePath)) {
            return true;
        } else {
            console.log("WARNNING, " +
                "module = config, " +
                "function = validateConfigurationPath, " +
                "configfile = " + configFilePath + ", " +
                "msg = Missing user defined configuration file");
        }
    }

    // When no user defined file, check if default root folder configuration exists
    configFilePath = path.join(config.rootDir, 'wf-config.json');

    // If no exception - ROOT file exists
    if (fs.existsSync(configFilePath)) {
        process.env.WF_CONFIG_FILE_PATH = configFilePath;
        return true;
    } else {
        console.log("WARNNING, " +
            "module = config, " +
            "function = validateConfigurationPath, " +
            "configfile = " + configFilePath + ", " +
            "msg = Missing root configuration file");
    }

    return false;
}


function mandatoryRootEnvs(configFile) {
    // Make sure that we specify database prefix during development
    var dbPrefixForDevelopment="";
    if (configFile.env) {
        dbPrefixForDevelopment=configFile.env.WF_DB_NAME_PREFIX;
    } else {
        configFile.env = {};
    }

    configFile.env.isDBPrefixResolved = configFile.env.isDBPrefixResolved || false;

    if (!configFile.env.isDBPrefixResolved) {
        dbPrefixForDevelopment = process.env.WF_DB_NAME_PREFIX || dbPrefixForDevelopment;

        if (!dbPrefixForDevelopment || ("" == dbPrefixForDevelopment)) {
            console.log("WARNNING, " +
                "module = config, " +
                "function = mandatoryRootEnvs, " +
                "configfile = " + process.env.WF_CONFIG_FILE_PATH + ", " +
                "msg = Missing database prefix WF_DB_NAME_PREFIX, aborting");
            process.exit(-2);
        }
        else if (dbPrefixForDevelopment.toUpperCase() === "false".toUpperCase()) {
            // For production we ask to set the env value to 'false'
            // so that we can use raw database names
            dbPrefixForDevelopment = "";
        } else {
            if (!(dbPrefixForDevelopment.substr(-1) === "-")) {
                dbPrefixForDevelopment = dbPrefixForDevelopment + "-";
            }
        }
        configFile.env.isDBPrefixResolved = true;
        configFile.env.WF_DB_NAME_PREFIX = dbPrefixForDevelopment;
    }
}

////////////////////////////////////
/////       Cedentials         /////
////////////////////////////////////

// synchrously (BLOCKING) - get credentails of bluemix application '{prefix}-api'
config.populateGlobalCredentialsFromServerSync = function (targetApp) {
    var stdout = execsync("cf env " + targetApp);
    if (stdout) {
        parseCFEnvCommandOutput(stdout.toString());
    }
};

// asynchrously - get credentails of bluemix application '{prefix}-api'
config.populateGlobalCredentialsFromServer = function (targetApp, callback) {
    exec("cf env " + targetApp, function (error, stdout, stderr) {
        if (error) {
            console.log("ERROR, " +
                "module = config, " +
                "function = populateGlobalCredentialsFromServer, " +
                "msg = Failed to get SERVER " + targetApp + " credentials ");
        } else {
            parseCFEnvCommandOutput(stdout);
        }
        if (callback) callback();
    });
};


module.exports = config;

// Utility Function that converts unicode that recieved form 'cf env' to character
// For instances:
// "iotf-service": [
//      {
//         "name": "iot4i-iotf-service",
//         ......
//         "credentials": {
//             .....
//            "apiKey": "a-959u6d-aehvr9zbbo",
//            "apiToken": "tzyFXj-JPICweXr&4p"    // e,g \\u00264  -> &
//         }
//      }
//   ],
function unicodeToChar(text) {
    return text.replace(/\\\\u[\dA-F]{4}/gi,
        function (match) {
            return String.fromCharCode(parseInt(match.replace(/\\\\u/g, ''), 16));
        });
}


// The following accepts as input a string of the 'cf env <app-name>' shell command.
// Process it and sets both GLOBAL and VCAP_SERVICES variable
function parseCFEnvCommandOutput(stdoutAsString) {
    var regex = /{\s*\"VCAP_SERVICES\"\s*:.*\"VCAP_APPLICATION\"/;
    var b = JSON.stringify(stdoutAsString).replace(/\\n/g, " ").replace(/\\\"/g, "\"");
    var c = regex.exec(b);
    var text = "" + c;
    text = text.replace(/{\s*\"VCAP_APPLICATION\".*/, "");
    text = unicodeToChar(text);
    var targetcred = JSON.parse(text);
    if (targetcred != null && targetcred.VCAP_SERVICES) {
        GLOBAL.credentials = {
            warning: false
        };

        Object.keys(targetcred.VCAP_SERVICES).forEach(function (app) {
            GLOBAL.credentials[app] = targetcred.VCAP_SERVICES[app][0].credentials;
        });
        console.log("INFO, " +
            "module = config, " +
            "function = populateGlobalCredentialsFromServer, " +
            "msg = Config is setting up GLOBAL from server");

        if (process.env.VCAP_SERVICES === undefined) {
            console.log("INFO, " +
                "module = config, " +
                "function = populateGlobalCredentialsFromServer, " +
                "msg = Config is setting up VCAP_SERVICES");
            process.env.VCAP_SERVICES = JSON.stringify(targetcred.VCAP_SERVICES);
        }
    }

    parseSpaceNameAndId(stdoutAsString);
}

function parseSpaceNameAndId(stdoutAsString) {
    var regex = /{\s*\"VCAP_APPLICATION\"\s*:.*User-Provided:/;
    var b = JSON.stringify(stdoutAsString).replace(/\\n/g, " ").replace(/\\\"/g, "\"");
    var c = regex.exec(b);
    var text = "" + c;
    text = text.replace(/\s*User-Provided:.*/, "");
    text = unicodeToChar(text);
    var targetcred = JSON.parse(text);
    if (targetcred != null && targetcred.VCAP_APPLICATION) {
        let spaceName = targetcred.VCAP_APPLICATION.space_name;
        process.env.SPACE_NAME = spaceName;
        console.log("INFO, " +
        "module = config, " +
        "function = parseSpaceName, " +
        "msg = Config is setting up SPACE_NAME");

        let spaceId = targetcred.VCAP_APPLICATION.space_id;
        process.env.SPACE_KEY = spaceId;
        console.log("INFO, " +
        "module = config, " +
        "function = parseSpaceName, " +
        "msg = Config is setting up SPACE_ID");
    }

}
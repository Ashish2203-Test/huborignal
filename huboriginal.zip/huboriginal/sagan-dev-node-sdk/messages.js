/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

module.exports = {
	uncaught_error: "@WF1@Uncaught error. Error id %s.",	
	shield_engine_started: "@WF2@Shield Engine running on %s:%s.",
	action_engine_started: "@WF3@Action Engine running on %s:%s.",
	api_started: "@WF4@API running on %s:%s.",
	action_egine_process_payload_error: "@WF5@Failed to get shield association. Error id %s",
	run_shield_error: "@WF6@Run shield error for shield %s. Error id %s",
	save_hazard_error: "@WF7@Failed saving hazard. Error id %s",
	send_hazard_error: "@WF8@Failed sending hazard to MQTT. Error id %s",
	iotf_error: "@WF9@IoTF Error. Error id %s"
};
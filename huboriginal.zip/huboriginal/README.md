[![node](https://img.shields.io/badge/Watson Personal Assistant-0.7-yellowgreen.svg)]() [![node](https://img.shields.io/badge/node-6.10.10-yellow.svg)]() [![NPM](https://img.shields.io/badge/npm-3.10.10-yellow.svg)]() [![Build Status](https://travis.ibm.com/ConsumerIoT/SaganCore.svg?token=eBM4ULW7rxEZxaXtxYQp&branch=master)](https://travis.ibm.com/ConsumerIoT/SaganCore) [![License](https://img.shields.io/badge/license-APACHE2-blue.svg)]()

## DISCLAIMER

THIS IS INITIAL VERSION OF THE Watson Personal Assistant. NOT EVERYTHING IS SUPPORTED AND NOT EVERYTHING IS DEBUGGED.
IF SOMETHING IS NOT WORKING, YOU CAN EITHER FIX IT AND SEND A PULL REQUEST OR YOU CAN ASK REPORT AN ISSUE TO THE Watson Personal Assistant TEAM.


## Table of Contents
* [Intro](#intro)
* [URLs and environments](#urls-and-environments)
* [Accessing with API Key](#accessing-with-api-key)
* [Routes and Services](#routes-and-services)
* [Logs](#logs)
* [Run locally](#run-locally)

![Top](/docs/images/top.jpg)


## Intro

The Hub is the main entrance for the client into the service.
The Hub has two main responsibilities:

- To identify the tenant (with the [API key](#accessing-with-api-key)) and authorize it's request
- To route the request to the wanted [Service](#routes-and-services)

## URLs and environments
We have 3 main environments:

#### Production

   - https://personal-assistant-toolkit.mybluemix.net
   - https://personal-assistant-kit.mybluemix.net
   - https://wpak.mybluemix.net
   - https://watson-personal-assistant-toolkit.mybluemix.net
   - https://watson-personal-assistant-kit.mybluemix.net
   - https://wpab.mybluemix.net
   - https://watson-personal-assistant-builder.mybluemix.net
   
#### Test
   - https://test-sagan-hub.mybluemix.net
#### Development
   - https://dev-sagan-hub.mybluemix.net
   
## Accessing with API Key

In order to access the watson personal assistant service you need to register and get an API key.
Unless you use that key you will be unauthorized by the service.
There are 2 ways to do that:
- URL query parameter - this way is to support the swagger web page.
    Just add a parameter at the end of every url with ?api_key=<< key >>
- Request header - another way is to add a header to the request.
    This can be done by adding the header "api_key" to the request and the value is the key

## Routes and Services

At the moment there are 3 services that the hub is referring to:

- [Core](https://github.ibm.com/ConsumerIoT/SaganCore)
- [Knowledge Query](https://github.ibm.com/ConsumerIoT/KnowledgeAndReasoning)
- [Message Broker](https://github.ibm.com/ConsumerIoT/sagan-message-broker)

## Logs

So far the Core used to be an independent instance that lives in the customer space and the customer could see the logs (that are very useful for debugging).
Now that the core is located behind a proxy (the hub) there is a need to expose that to the user.
The logs now available through https://<< hub address >>/logs

## Deploy
#### Deploying the hub to Bluemix
The hub is like any instance in Bluemix, but there is only one instance per space.

- Clone SaganHub from GitHub ```git clone https://github.ibm.com/ConsumerIoT/SaganHub```

- Change to hub folder ```cd SaganHub```

- Change to Deploys Folder ```cd Deploys```
    In order to keep track with all of the environments and their deploys (in case of an update)
    we have created a folder that holds hierarchically (organization/space) all the deploy files.
    Create new folders according to your Bluemix environment, copy the files and change accordingly.
    The "name" parameter in the yml file MUST be "sagan-hub"
    Note that you have to create a Cloudant service before executing the deploy script. 

- Login to the correct environment in Bluemix with  ```cf login```

- Run the push script file

#### Deploying a new Core

Another thing that you find in the ```Deploys``` folder is the core creation scripts.
Since there must be a hub in the Bluemix space in order for the core to work and the hub is managing the cores anyway,
 the scripts are located here.
 
 Just run in terminal ```./create.sh``` and follow the instructions.
 At the end of the execution you will get the new core's name (not intended for the customer)
 and the API key - without it the customer can't access the service, so provide that key to the customer (preferably via a secure message)

## Run locally
Since the hub uses Cloudant Database to load and save its configuration it first need to be deployed to Bluemix.

- Clone SaganHub from GitHub ```git clone https://github.ibm.com/ConsumerIoT/SaganHub```

- Change to hub folder ```cd SaganHub```

- Run ```npm install```

- Login to the correct environment in Bluemix with  ```cf login```

- Start Sagan Hub by running ```npm run dev-local```

## Maintainers

Dean Haber - [deanh@il.ibm.com](deanh@il.ibm.com)

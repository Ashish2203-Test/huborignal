var Cloudant = require('cloudant');
let wfconfig = require('../iam-config.json');

let IAM_DB = 'iam';

let cloudant;
function init(env, callback) {
    cloudant = Cloudant({
        url: wfconfig.iam.bmxEnv[env].cloudantDB.db_url,
        plugin: 'retry',
        retryAttempts: 10
    });
}

function validateClientId(env, clientid, callback) {
    let db = cloudant.db.use("routes", function(err, data) {
        if (err) {
            console.log("Table not found::", err);
            return callback(err, null);
        }
    });

    db.find({
        selector: {
            clientID: clientid
        }
    }, function(err, doc) {
        if (doc.docs.length > 0) {
            console.log("Validated specified client Id");
            return callback(null, true);
        } else {
            console.log("The specified client Id is not found");
            return callback(err, null);
        }
    });
}

findAccessRecord = function(clientId, bmxId, callback) {
    var db = cloudant.db.use(IAM_DB, function(err, data) {
        if (err) {
            console.log("Table not found: " + JSON.stringify(err));
            return callback(err, null);
        }
    });

    let viewName = 'searchByBMXIdAndClientId';
    var viewOptions = {};
    viewOptions.keys = [[bmxId, clientId]];
    viewOptions.include_docs = true;

    db.view("IAMView", viewName, viewOptions, function (err, docs) {
        if (err) {
            console.log("Error searching record," + err);
            return callback(err, null);
        } else if (docs.rows.length > 1) {
            return callback(null, docs.rows[0]);
        } else {
            return callback(null, docs.rows[0]);
        }
    });
};

addNewAccessRecord = function(clientId, bmxId, iamId, callback) {
    console.log('Creating access record in cloudant...');

    var db = cloudant.db.use(IAM_DB, function(err, data) {
        if (err) {
            console.log("Table not found::", err);
            return callback(err, null);
        }
    });

    findAccessRecord(clientId, bmxId, function(err, rec) {
        if (err) {
            return callback(err, null);
        }

        if (rec) {
            return callback('Access record already created in cloudant', null);
        } else {
            var newAccessRecord = {};
            newAccessRecord.clientId = clientId;
            newAccessRecord.iamId = iamId;
            newAccessRecord.bmxId = bmxId;

            db.insert(newAccessRecord, function(err2, result) {
                if (err2) {
                    callback(err2, null);
                } else {
                    callback(null, newAccessRecord);
                }
            })

        }
    });
};

deleteAccessRecord = function(clientId, bmxId, callback) {
    var db = cloudant.db.use(IAM_DB, function(err, data) {
        if (err) {
            console.log("Table not found::", err);
            return callback(err, null);
        }
    });

    findAccessRecord(clientId, bmxId, function(err, rec) {
        if (err) {
            return callback(err, null);
        }

        if (rec) {
            // console.log('rec = ' + JSON.stringify(rec));

            db.destroy(rec.doc._id, rec.doc._rev, function(err, body, header) {
                if (err) {
                    callback(err, null);
                } else {
                    callback(null, 'Successfully removed access record from cloudant');
                }
            });
        } else {
            return callback('Access record not found in cloudant', null);
        }
    });
};

module.exports.validateClientId = validateClientId;
module.exports.addNewAccessRecord = addNewAccessRecord;
module.exports.init = init;
module.exports.deleteAccessRecord = deleteAccessRecord;
var Client = require('node-rest-client').Client;
let wfconfig = require('../iam-config.json');
var client = new Client();

function getToken(env, callback) {
    var args = {
        data: wfconfig.iam.bmxEnv[env].service_api_key_data_script,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json"
        }
    };

    console.log('Generating access token, using WPA service api key. Target IAM:', wfconfig.iam.bmxEnv[env].oidc_url);
    client.post(wfconfig.iam.bmxEnv[env].oidc_url, args, function(data, response) {
		 if (!data.errors && data != null) {
            return callback(null, data.access_token);
        }
        if (data.errors) {
            console.log("Unable to genrate access token", data);
            return callback(data.errors, null);
        }
    });

}

function grantAccess(env, iamId, role, token, callback) {
    var provision_url = wfconfig.iam.bmxEnv[env].pap_url + "scopes/a%2F" + wfconfig.iam.bmxEnv[env].account + "/users/" + iamId + "/policies";
    console.log("Granting access to user:", iamId, " to env:", env, " for IAM:", provision_url);
    var args = {
        data: {
            "roles": [{
                'id': role
            }],
            "resources": [{
                "serviceName": wfconfig.iam.bmxEnv[env].serviceName
            }]
        },

        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': "Bearer " + token
        }
    };

    client.post(provision_url, args, function(data, response) {
        if (!data.errors && data != null) {
            console.error("Successfully granted access to: " + iamId);
            return callback(null, data);
        }

        if (data.errors) {
            console.error("Error while granting access to: " + iamId);
            return callback(data.errors, null);
        }
    })
}

function revokeAccess(env, iamId, token, callback) {
    console.log('Revoking access from IAM...');
    callback(null, 'Dummy response for revoke access');
}

function getServiceRevision(env, token, callback) {
    var service_url = wfconfig.iam.bmxEnv[env].pap_url + "services/" + wfconfig.iam.bmxEnv[env].serviceName;
    var args = {
        headers: {
            "Accept": "application/json",
            "Authorization": "Bearer " + token
        }
    };

    console.log('Getting service revision number for Service url: ', service_url);

    client.get(service_url, args, function(data, response) {
        if (response.headers.etag != null) {
            var etag = response.headers.etag;
            console.log('Current Revision :' + etag);
            return callback(null, etag)
        } else {
            console.log("Error : Unable to get etag to update service actions");
            return callback(data, null);
        }

    });
}

function registerServiceAction(env, etag, token, callback) {
    var actions = require('./wpa-action.json');
    var args = {
        data: actions,
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer " + token,
            "If-Match": etag
        }
    };
    var service_url = wfconfig.iam.bmxEnv[env].pap_url + "services/" + wfconfig.iam.serviceName;
    console.log("Registering Service actions into IAM...");

    client.put(service_url, args, function(data, response) {
        if (!data.errors) {
            console.log('Service action policy registered successfully: ' + JSON.stringify(data));
            return callback(null, data);
        } else {
            console.log('Error while Service action policy registration. Action: ',data, args.data.actions[0].id, ', Status code:', data.errors[0].statusCode, ', Message:', data.errors[0].description);
            return callback(data.errors, null);
        }
    });

}

module.exports.grantAccess = grantAccess;
module.exports.revokeAccess = revokeAccess;
module.exports.getToken = getToken;
module.exports.getServiceRevision = getServiceRevision;
module.exports.registerServiceAction = registerServiceAction;

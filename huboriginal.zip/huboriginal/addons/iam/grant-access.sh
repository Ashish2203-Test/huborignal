#!/bin/bash

echo "Please login to the target space (sagan-hub must be present in that space)"

space=$(cf t | sed -e '$!d' | awk '{print $NF}')
org=$(cf t | sed '$d' | sed '$!d' | awk '{print $NF}')

for i in "$@"
do
case $i in
    -i=*|--iamId=*)
    IAM_ID="${i#*=}"
    ;;

    -r=*|--role=*)
    ROLE="${i#*=}"
    ;;

    -e=*|--env=*)
    ENV="${i#*=}"
    ;;

    -b=*|--bmxId=*)
    BMX_ID="${i#*=}"
    ;;

    -c=*|--clientId=*)
    CLIENT_ID="${i#*=}"
    ;;
    *)
    ;;
esac
done

echo IAM ID = ${IAM_ID}
echo ROLE = ${ROLE}
echo ENV = ${ENV}
echo BMX ID = ${BMX_ID}
echo CLIENT ID = ${CLIENT_ID}

params=$(WF_DEPLOY_DIRECT_TARGET_PREFIX=sagan-hub CLIENT_ID=$CLIENT_ID IAM_ID=$IAM_ID ROLE=$ROLE ENV=$ENV BMX_ID=$BMX_ID node iamGrantAccess.js);

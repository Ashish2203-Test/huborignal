const commandLineArgs = require('command-line-args');
const route = require('./util/route.js');
const iamUtil = require('./util/iam-util.js');
let bl = require("sagan-dev-node-sdk").bl;

/*
const optionDefinitions = [
	{ name: 'iamId', alias: 'i', type: String },
	{ name: 'role', type: String, alias: 'r'},
	{ name: 'env', alias: 'e', type: String },
	{ name: 'bmxId', alias:'b', type:String },
	{ name: 'clientId', alias:'c', type:String }
];

const options = commandLineArgs(optionDefinitions);
if (!options.iamId || !options.role || !options.env || !options.bmxId || !options.clientId) {
	console.log('Usage: node iam-grant-policy --env [staging | production | production-dev | production-test | production-test ] --iamId <User IAM Id> --role [Manager | Writer | Reader] --bmxId <Bluemix Id> --clientId <clientId in cloudant db>');
	process.exit(1);
} 

var role;

if( options.role == 'Administrator' || options.role == 'Editor' || options.role == 'Viewer' ){
	role = "crn:v1:bluemix:public:iam::::role:" + options.role
}else if (options.role == 'Manager' || options.role == 'Reader' || options.role == 'Writer'){
	role = "crn:v1:bluemix:public:iam::::serviceRole:" + options.role
}else {
	console.log('Usage: node iam-grant-policy --env [staging | production | production-dev | production-test] --iamId <User IAM Id> --role [Manager | Writer | Reader] --bmxId <Bluemix Id> --clientId <clientId in cloudant db>');
	process.exit(1);
}


if(!route.cloudantConn(options.env)){
	console.error("Cloduant information is missing");
	process.exit(1);
}
*/

let clientId = process.env.CLIENT_ID;
let role = process.env.ROLE;
let bmxId = process.env.BMX_ID;
let iamId = process.env.IAM_ID;

console.log('Validating client Id...');
bl.route.getClientRecFromClientId(options.clientId, function(err, crec) {
	if(crec) {
		iamUtil.getToken(options.env, function(err, token) {
			if(token) {
				iamUtil.grantAccess(options.env, options.iamId, role, token, function(err,data) {
					if(data) {
						bl.iam.addNewAccessRecord(clientId, iamId, bmxId, function(err, result) {
							if(result){
								console.log("Access granted successfully to : " + bmxId );
							}
						});
					}
				});
			}
		})
	}
});

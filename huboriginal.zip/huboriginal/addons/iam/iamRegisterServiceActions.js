const commandLineArgs = require('command-line-args');
const iamUtil = require('./util/iam-util.js');

const optionDefinitions = [
    { name: 'env', alias: 'e', type: String }
];

const options = commandLineArgs(optionDefinitions);
if (!options.env) {
    console.log('Usage: node iam-register-service-actions --env [staging | production | production-dev | production-test | production-staging]');
    process.exit(1);
}

iamUtil.getToken(options.env, function(err, accessToken) {
	if(accessToken) {
		iamUtil.getServiceRevision(options.env, accessToken, function(error, etag) {
			if(etag) {
				iamUtil.registerServiceAction(options.env, etag, accessToken, function(error, data) {
					if(error) {
						console.error("Service registration failed: " + JSON.stringify(error));
					}
				});
			}
		});
	}
});

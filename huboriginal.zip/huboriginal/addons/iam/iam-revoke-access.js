const commandLineArgs = require('command-line-args');
const iamUtil = require('./util/iam-util.js');
const bl = require('./util/bl.js');

const optionDefinitions = [
	{ name: 'env', alias: 'e', type: String },
	{ name: 'bmxId', alias:'b', type: String },
	{ name: 'clientId', alias:'c', type: String }
];

const options = commandLineArgs(optionDefinitions);
if (!options.env || !options.bmxId || !options.clientId) {
	console.log('Usage: node iam-revoke-access --env [staging | production | production-dev | production-test | production-test ] --bmxId <Bluemix Id> --clientId <clientId in cloudant db>');
	process.exit(1);
} 

bl.init(options.env);

console.log('Validating client Id...');
bl.validateClientId(options.env, options.clientId, function(err, isExist) {
	if(isExist) {
		iamUtil.getToken(options.env, function(err, token) {
			if(token) {
				iamUtil.revokeAccess(options.env, options.iamId, token, function(err, data) {
					if(data) {
						bl.deleteAccessRecord(options.clientId, options.bmxId, function(err, result) {
							if (err) {
								console.error('Error: ' + err);
							} else if(result) {
								console.log("Removed access record from cloudant");
							}
						});
					}
				});
			}
		})
	}
});

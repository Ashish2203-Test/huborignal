'use strict';
let Client = require('node-rest-client').Client;
let request = require('request');
let bl = require("sagan-dev-node-sdk").bl;
let config = require('./iam-config.json');
let UrlPattern = require('url-pattern');
let redis = require('../../cache');
let md5 = require('md5');
let URL = require('url');

let iam_enabled = process.env.ENABLE_IAM;
if (iam_enabled !== undefined && iam_enabled.toLowerCase() === 'true') {
    console.log('IAM is ENABLED');
    iam_enabled = true;
} else {
    console.log('IAM is DISABLED');
    iam_enabled = false;
}

let bmx_env = process.env.BMX_ENV || "production-dev";
console.log('Targeted env:', bmx_env);

/**
 * Parameters for web auth and authz
 */
let REDIRECT_URI = config.iam.bmxEnv[bmx_env].iam_redirect_uri;
console.log('REDIRECT_URI = ' + REDIRECT_URI);

let REDIRECT_URL = config.iam.bmxEnv[bmx_env].iamUrl_web + '/identity/authorize?client_id=' + config.iam.bmxEnv[bmx_env].clientId + '&redirect_uri=' + REDIRECT_URI;
console.log('REDIRECT_URL = ' + REDIRECT_URL);

let client = new Client();

/**
 * Create md5 hash
 * @param value
 * @returns {null}
 */
function getHash(value) {
    if (value)
        return md5(value);
    else
        return null;
}

let action;
function isAuthorized(request, callback) {
      if (request.session && request.session.clientRec) {
        console.log('User is already authenticated. Found client record in session');
        return callback(null, request.session.clientRec);
    } else {
        console.log('User is NOT authenticated. No client record found in session');
    }

    action = config.iam.resourcesToActionsMapping
        .find(function(ele) {
            return ele.httpVerb === request.method;
        })
        .action;

    if (!action) {
        return callback('Action not allowed on resource', null)
    }

    // console.log('Action:', action);

    if (!request.headers.authorization) {
        return callback('Authorization header not present', null);
    }

    // console.log('Header:', request.headers.authorization);

    if (!request.headers.authorization.length) {
        return callback('Authorization header invalid value', null);
    }

    if (request.headers.authorization.indexOf('Bearer') === -1) {
        return callback('Authorization header invalid value', null);
    }

    if (request.headers.authorization.split(' ').length !== 2) {
        return callback('Access token not specified', null);
    }

    const token = request.headers.authorization.split(' ')[1];
    if (!token) {
        return callback('Authorization access token invalid value', null);
    }

    let tokenHash = getHash(token);
    redis.getObject(tokenHash, function(err, userAccessToken) {
        if (err) {
            console.error('Could not get user access token from redis:', err);
        }

        if (userAccessToken) {
            console.log('userAccessToken from redis:', userAccessToken);
            onReceivedTokenInfo(userAccessToken, {});
        } else {
            var args = {
                data: {
                    'token': token
                },
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            };

            console.log('Getting user profile from access token');
            client.post(config.iam.bmxEnv[bmx_env].introspect_url, args, onReceivedTokenInfo);
        }
    });

    function onReceivedTokenInfo(tokenInfo, response) {
        if (!tokenInfo) {
            return callback('Invalid token', null);
        }

        if (tokenInfo.errors) {
            return callback(tokenInfo.errors[0].message, null);
        }

        if (tokenInfo.active && tokenInfo.active === false) {
            return callback('Access token expired', null);
        }

        redis.keyExists(tokenHash, function(exists) {
            if (!exists) {
                let store = {
                    sub: tokenInfo.sub,
                    iam_id: tokenInfo.iam_id
                };
                redis.putObject(tokenHash, store, 120);
            }
        });

        // console.log('tokenInfo:', tokenInfo);

        if (!tokenInfo.sub || !tokenInfo.iam_id) {
       	 	 return callback('Access token expired', null);
       	 	}


        console.log('Validating tokenInfo.sub:', tokenInfo.sub);

        let clientId = request.headers.clientid;
        console.log('Finding access record, clientId = ', clientId, ' ,tokenInfo.iam_id = ', tokenInfo.iam_id);
        bl.iam.findAccessRecord(clientId, tokenInfo.iam_id, function(err, accessRec) {
            if (!accessRec) {
                console.log('No access record found for ' + tokenInfo.iam_id);
                return callback('Not authorized', null);
            }

            // console.log('accessRec:' + JSON.stringify(accessRec));
            clientId = accessRec.clientId;

            if (iam_enabled) {
                if (isWhiteListed(request)) {
                    return getClientRecord(accessRec.clientId, accessRec.bmxId, callback);
                }

                redis.getObject('srvAccessToken', function(err, srvAccessToken) {
                    if (err) {
                        console.error('Could not get service access token from redis:', err);
                    }

                    if (srvAccessToken) {
                        console.log('Retrieved service access token from cache = ', JSON.stringify(srvAccessToken));
                        return checkAuthz(accessRec.clientId, srvAccessToken.access_token, tokenInfo, callback);
                    } else {
                        var args = {
                            data: config.iam.bmxEnv[bmx_env].service_api_key_data,
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded",
                                "Accept": "application/json"
                            }
                        };

                        console.log('Generating access token for service api key...');
                        var req = client.post(config.iam.bmxEnv[bmx_env].oidc_url, args, function(data, response) {
                            if (data != null && (!data.errors)) {
                                let storeObj = {
                                    access_token: data.access_token
                                };
                                redis.putObject('srvAccessToken', storeObj, 60);

                                return checkAuthz(accessRec.clientId, data.access_token, tokenInfo, callback);
                            } else {
                                return callback('Access denied for user' + tokenInfo.sub, null);
                            }
                        });

                        req.on("responseTimeout", function(res){
                            return callback(res, null);
                        });
                    }
                });
            } else {
                return callback(null, clientRec);
            }
        });

    }
}

function checkAuthz(clientId, srvAccessToken, userTokenInfo, callback) {
    console.log('checking authz, clientId =' + clientId + ', srvAccessToken =' + JSON.stringify(srvAccessToken) + ', userTokenInfo =' + JSON.stringify(userTokenInfo));
    prepv2Authz(srvAccessToken, userTokenInfo, function(err, res) {
        if (err)
            return callback(err, null);

        if (res && (res == true || res == 'true'))
            return getClientRecord(clientId, userTokenInfo.sub, callback);
        else
            return callback("Access denied for user, ", userTokenInfo.sub);
    });
}

function getClientRecord(clientId, bmxId, callback) {
    console.log('Getting client record, clientId = ' + clientId + ', bmxId = ' + bmxId);
    bl.route.getClientRecFromClientId(clientId, function(core) {
        if (!core) {
            return callback('Access denied', null);
        }

        core.bmxId = bmxId;
        return callback(null, core);
    });
}

/**
 * check if the api is white listed and allowed without authz
 * @param req
 * @returns {boolean}
 */
function isWhiteListed(req) {
    for (let path in config.iam.whiteListedApis) {
        var pattern = new UrlPattern(config.iam.whiteListedApis[path].url);
        if (pattern.match(req.url) != null) {
            console.log('Api is white listed, ', req.url);
            return true;
        }
    }

    return false;
}

/**
 * authz using v2 apis - recommended to use
 * @param token
 * @param tokeninfo
 * @param callback
 */
function prepv2Authz(token, tokeninfo, callback) {
    let access_key = tokeninfo.iam_id + '__' + action;
    redis.getKey(access_key, function(err, decision) {
        // console.log('decision from redis:', decision);

        if (err) {
            console.error('Could not get previous decision about authz for key:', access_key);
        }

        if (decision) {
            console.log('Found earier decision about authz:', decision);
            callback(null, decision);
        } else {
            console.log('Getting new decision about authz for key:', access_key);
            // console.log('srvAccessToken:', token);
            // console.log('user info:', tokeninfo);

            var options = {
                method: 'POST',
                url: config.iam.bmxEnv[bmx_env].v2authz_url,
                headers: {
                    'authorization': 'Bearer ' + token,
                    'cache-control': 'no-cache',
                    'accept': 'application/vnd.authz.v2+json',
                    'content-type': 'application/json'
                },
                body: [{
                    'action': action,
                    'environment': {},
                    'resource': {
                        'attributes': {
                            'serviceName': config.iam.bmxEnv[bmx_env].serviceName,
                            'accountId': config.iam.bmxEnv[bmx_env].account
                        }
                    },
                    'subject': {
                        'iamId': {
                            'userId': tokeninfo.iam_id
                        }
                    }
                }],
                json: true
            };

            request(options, function(error, response, body) {
                if (error) {
                    callback(error, null);
                }
                else {
                    // console.log('Authz response body: ' + JSON.stringify(body));

                    if (body.errors && body.errors[0]) {
                        console.error('Error while getting authz response: ' + JSON.stringify(body.errors));
                        callback(body.errors[0].code + ':' + body.errors[0].code, null);

                    } else {
                        console.log("PAP auth response = ", body.responses[0].authorizationDecision.permitted);
                        redis.putKey(access_key, body.responses[0].authorizationDecision.permitted, 60);
                        callback(null, body.responses[0].authorizationDecision.permitted);
                    }
                }
            });

        }
    });
}

function login(req, res) {
    console.log('login, Redirecting to ' + REDIRECT_URL);
    res.writeHead(301, {Location: REDIRECT_URL});
    res.end();
}

function authCallback(req, res) {
    console.log('authCallback, Start handling authz callback..');

    handleAuthorizeCallback(req, res, function (err) {
        if (!err) {
            var html = '<div align="right">' +
                '<span>' + req.session.clientRec.fullname + '</span> | <span>' + req.session.clientRec.bmxId + '</span>' +
                '</div>' +
                '<div class="authorized">' +
                'Welcome to the Watson Personal Assistant Builder <br><br>' +
                '<a href="https://pages.github.ibm.com/ConsumerIoT/developer/" rel="noreferrer" target="_blank">Documentation</a><br><br>' +
                '<a href="/docs/" rel="noreferrer" target="_blank">Core Swagger page</a><br><br>' +
                '<a href="/logs/" rel="noreferrer" target="_blank">Core Logs</a><br><br>' +
                '<a href="/knowledge/apidocs/" rel="noreferrer" target="_blank">Knowledge Store Swagger Page</a><br><br>' +
                '<a href="/agent/apidocs/" rel="noreferrer" target="_blank">Agent Subscription Swagger Page</a>' +
                '</div>';
            res.writeHead(200, {"Content-Type": "text/html"});
            res.write(html);
            res.end();
        }
    });
};

function handleAuthorizeCallback(req, res, callback) {
    console.log('Parsing req.url ' + req.url);

    let query = (URL.parse(req.url, true)).query;
    console.log("handleAuthorizeCallback, query = ", query);

    let code = query.code;
    console.log("AuthorizeCallback with code = " + code);

    // Set the headers
    let headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'Authorization': "Basic " + new Buffer(config.iam.bmxEnv[bmx_env].clientId + ":" + config.iam.bmxEnv[bmx_env].clientSecret, "utf8").toString("base64")
    };

    // Request parameters
    let options = {
        url: config.iam.bmxEnv[bmx_env].iamUrl_web + '/identity/token',
        method: 'POST',
        headers: headers,
        form: {
            'client_id': config.iam.bmxEnv[bmx_env].clientId,
            'client_secret': config.iam.bmxEnv[bmx_env].clientSecret,
            'grant_type': 'authorization_code',
            'response_type': 'cloud_iam',
            'code': code,
            'redirect_uri': REDIRECT_URI
        }
    };

    console.log('Posting request for authz = ', options);

    // Start the request
    let accessToken = 'Failed';
    let userAccessToken;

    request(options, function (error, response, body) {
        console.log('Response from IAM = ' + JSON.stringify(body));
        let results = '?results=';

        if (!error && response.statusCode == 200) {
            // Parse the IAM token and redirect to the done page
            userAccessToken = JSON.parse(body);
            console.log('userAccessToken = ' + JSON.stringify(userAccessToken));

            accessToken = 'bearer ' + userAccessToken.access_token;
            console.log('Access token = ' + accessToken);

            var args = {
                data: {
                    'token': userAccessToken.access_token
                },
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            };

            client.post(config.iam.bmxEnv[bmx_env].introspect_url, args, onReceivedToken);
        } else {
            results += 'error';
            let redirectUrl = '/' + results;
            console.log("Redirecting to " + redirectUrl);

            res.writeHead(301, {Location: redirectUrl});
            res.end();
        }
    });

    function onReceivedToken(tokenInfo, response) {
        console.log('TokenInfo = ' + JSON.stringify(tokenInfo));

        if (tokenInfo != null && (!tokenInfo.errors)) {
            console.log('tokenInfo.sub = ' + tokenInfo.sub);

            // valid bmx id
            bl.iam.validateBMXId(tokenInfo.sub, function(iamRec) {
                console.log('iamRec = ' + JSON.stringify(iamRec));
                if (!iamRec) {
                    return callback('Not authorized');
                }

                bl.route.getClientRecFromClientId(iamRec.clientId, function(clientRec) {
                    if (!clientRec) {
                        return callback('Not authorized');
                    }

                    console.log('clientRec = ' + JSON.stringify(clientRec));

                    req.session.clientRec = clientRec;
                    req.session.clientRec.fullname = tokenInfo.name;
                    req.session.clientRec.bmxId = iamRec.bmxId;
                    req.session.accessToken = userAccessToken;

                    return callback();
                });
            });
        } else {
            console.log(" onReceivedTokenInfo error ");
            return callback(tokenInfo.errors[0].message);
        }
    }
}

module.exports.isAuthorized = isAuthorized;
module.exports.login = login;
module.exports.authCallback = authCallback;

const commandLineArgs = require('command-line-args');
const iamUtil = require('./util/iam-util.js');
const bl = require('./util/bl.js');

const optionDefinitions = [
	{ name: 'iamId', alias: 'i', type: String },
	{ name: 'role', type: String, alias: 'r'},
	{ name: 'env', alias: 'e', type: String },
	{ name: 'bmxId', alias:'b', type: String },
	{ name: 'clientId', alias:'c', type: String }
];

const options = commandLineArgs(optionDefinitions);
if (!options.iamId || !options.role || !options.env || !options.bmxId || !options.clientId) {
	console.log('Usage: node iam-grant-policy --env [staging | production | production-dev | production-test | production-test ] --iamId <User IAM Id> --role [Manager | Writer | Reader] --bmxId <Bluemix Id> --clientId <clientId in cloudant db>');
	process.exit(1);
} 

var role;
if (options.role == 'Manager' || options.role == 'Reader' || options.role == 'Writer'){
	role = "crn:v1:bluemix:public:iam::::serviceRole:" + options.role
}else {
	console.log('Usage: node iam-grant-access --env [staging | production | production-dev | production-test] --iamId <User IAM Id> --role [Manager | Writer | Reader] --bmxId <Bluemix Id> --clientId <clientId in cloudant db>');
	process.exit(1);
}

bl.init(options.env);

console.log('Validating client Id...');
bl.validateClientId(options.env, options.clientId, function(err, isExist) {
	if(isExist) {
		iamUtil.getToken(options.env, function(err, token) {
			if(token) {
				iamUtil.grantAccess(options.env, options.iamId, role, token, function(err,data) {
					if(data) {
						bl.addNewAccessRecord(options.clientId, options.bmxId, options.iamId, function(err, result) {
							if (err) {
								console.error('Error: ' + err);
							} else if(result) {
								console.log("Created access record in cloudant");
							}
						});
					}
				});
			}
		})
	}
});

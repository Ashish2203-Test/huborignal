/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var basebl = require('sagan-dev-node-sdk').bl.base;
var BASE = new basebl('core');
const uuidV4 = require('uuid/v4');

/////////////////////////////////////
/*
create new core and upload it to bluemix
generate an api key and attach the key to the core (via the db)
 */
/////////////////////////////////////

var coreDetails = {
    "apikey": uuidV4(),
    "coreUrl": "",
    "persistantData": {}
};

db = BASE;
db.AddCore(coreDetails);

db.AddCore = function (coreDetails, callback) {
    var self = db;
    self.insert(coreDetails, function (err, results) {
        if (err) {
            console.log("Error inserting the new core details to the DB " + err);
            callback(null);
        } else {
            callback(results);
        }
    });
};

module.exports = db;
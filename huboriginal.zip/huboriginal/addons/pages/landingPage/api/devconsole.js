export default class ApiDevConsole {

  static devconsole(ApiKey) {
    console.log("API devconsole")
    return new Promise((resolve, reject) => {
      fetch('/v2/api/skillSets/?api_key='+ApiKey+'#')
        .then(function(response) {
          if (response.status == 200) {
            resolve(response.json());
          }
        }).catch(err => {
            reject('Error while loading data');
          });

    });
  }


  static converseData(collection, input, ApiKey) {
    console.log("chat", collection, input, ApiKey)
    let submitted = true;
    let chosenExpertise = '';
    let converseRequest = {
      'method': 'POST',
      'text': input,
      'language': 'en-US',
      'userID': 'application-14c',
      'deviceType': 'phone',
      'additionalInformation': {
        'context': {}
      }
    };
    return new Promise((resolve, reject) => {
      var request = new Request(
          '/v2/api/skillSets/'+collection+'/converse/?api_key='+ApiKey+'#', {
            method: 'POST',
            body: JSON.stringify(converseRequest)
          }
        );

      fetch(request)
      .then(function(response) {
        if (response.status == 200) {
          resolve(response.json());
        }
      }).catch(err => {
          reject('Error');
        });

    });

  }

}

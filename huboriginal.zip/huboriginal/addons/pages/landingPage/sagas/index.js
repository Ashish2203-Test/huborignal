import { takeLatest } from "redux-saga";
import { fetchExpertiseData, converseChat } from "./devconsole";
import { fork } from "redux-saga/effects";

export function* sagas() {
  yield [
    fork(takeLatest, 'FETCH_EXPERTISE_DATA', fetchExpertiseData),
    fork(takeLatest, 'CONVERSE_CHAT', converseChat)
  ];
}

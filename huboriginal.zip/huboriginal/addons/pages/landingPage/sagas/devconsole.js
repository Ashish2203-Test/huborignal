import ApiDevConsole from "../api/devconsole";
import { call, put } from "redux-saga/effects";

export function* fetchExpertiseData(action) {
  const ExpertiseData = yield call(ApiDevConsole.devconsole,action.payload);
   yield put({
  type: 'FETCH_EXPERTISE_DATA',
  ExpertiseData: ExpertiseData,
});

}


export function* converseChat(action) {
  const ConverseData = yield call(ApiDevConsole.converseData,action.collectionName,action.input, action.ApiKey);
   yield put({
  type: 'CONVERSE_CHAT',
  ConverseData: ConverseData,
});

}

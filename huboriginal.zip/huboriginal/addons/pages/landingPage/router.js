import React from "react";
import { history } from "./store.js";
import { Router, Route, IndexRoute } from "react-router";
import loginPage from "./components/loginPage";
import Devconsole from "./components/Devconsole";

const router = (
  <Router onUpdate={() => window.scrollTo(0, 0)} history={history}>
  <div>
    <Route exact path="/" component={loginPage}/>
    <Route path="/dev-console" component={Devconsole}/>
  </div>
  </Router>
);

export { router };

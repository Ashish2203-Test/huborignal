import "babel-polyfill";
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { store } from "./store.js";
import loginPage from "./components/loginPage";
import Devconsole from "./components/Devconsole";
import { router } from "./router.js";

// render the main component
ReactDOM.render(
  <Provider store={store}>
    {router}
  </Provider>,
  document.getElementById('app')
);

function mainDirective() {
    return {
        restrict: 'E', // C: class, E: element, M: comments, A: attributes
        replace: true, // replaces original content with template
        templateUrl: "landingPage/main.html",
        controller: mainController
    };
}

function mainController($scope, $http, $rootScope, $window, $log, $timeout, $document) {
    $scope.authorized = false;
    $scope.verifyKeyDisable = false;
    $scope.expertiseResponse = '';
    $scope.availableExpertise = [];
    $scope.availableCollections = [];
    $scope.selectedCollection = '';
    $scope.chosenExpertise = '';
    $scope.submitted = false;
    $scope.domain = 'https://' + window.location.hostname;

    if(window.location.port) {
        $scope.domain = $scope.domain + ':' + window.location.port;
    }

    function getConfig() {
        $http.get('/config/').then(function successCallback(response) {
            // console.log('Response ' + JSON.stringify(response.data));
            $scope.isIAMEnabled = response.data.iamEnabled;
        }, function errorCallback(err) {
            console.log('calling isIAMEnabled failed ' + JSON.stringify(err));
            $scope.isIAMEnabled = false;
        });
    }

    $scope.isIAMEnabled = false;
    getConfig();

    $scope.verifyKey = function () {
        if (!$scope.verifyKeyDisable) {
            $scope.verifyKeyDisable = true;
            $http.get('/validateKey/' + $scope.apikey).then(function successCallback(response) {
                var code = response.status;
                if (code === 200) {
                    $scope.authorized = true;
                    $scope.getAvailableCollections()
                }
            }, function errorCallback(response) {
                var code = response.status;
                if (code === 401) {
                    $scope.errorMessage = "Not authorized";
                } else {
                    $scope.errorMessage = "Unknown error";
                }

                $scope.verifyKeyDisable = false;
            });
        }
    };

    $scope.getAvailableCollections = function() {
        $scope.availableCollections = [];
        console.log($scope.domain + '/v2/api/skillSets/?api_key='+$scope.apikey);
        $http.get($scope.domain + '/v2/api/skillSets/?api_key='+$scope.apikey).then(
            function successCallback(response) {
                let code = response.status;
                if (code === 200) {
                    response.data.forEach(function(collection) {
                        $scope.availableCollections.push(collection.skillSet);
                    });
                }
            }, function errorCallback(response) {
                console.log(response);
                let code = response.status;
                if (code === 401) {
                    $scope.errorMessage = "Not authorized";
                } else {
                    $scope.errorMessage = 'Error, code:' + code.toString();
                }
            });
    };

    $scope.getAvailableExpertise = function(collectionName) {
        $scope.availableExpertise = [];
        if(collectionName) {
            $http.get($scope.domain + '/v2/api/skillSets/'+collectionName+'/?api_key='+$scope.apikey+'#').then(
                function successCallback(response) {
                    let code = response.status;
                    if (code === 200) {
                        $scope.availableExpertise = [];
                        response.data.skills.forEach(function(expertise) {
                           $scope.availableExpertise.push(expertise.name);
                        });
                    }
                    $scope.availableExpertise = $scope.availableExpertise.join(', ');
                }, function errorCallback(response) {
                    let code = response.status;
                    if (code === 401) {
                        $scope.errorMessage = "Not authorized";
                    } else {
                        $scope.errorMessage = 'Error, code:' + code.toString();
                    }
                });
        }
    };

    $scope.useConverse = function(userInput) {
        $scope.submitted = true;
        $scope.chosenExpertise = '';
        let converseRequest = {
            'text': userInput,
            'language': 'en-US',
            'userID': 'application-14c',
            'deviceType': 'phone',
            'additionalInformation': {
                'context': {}
            }
        };
        let url = $scope.domain + '/v2/api/skillSets/'+$scope.selectedCollection +'/converse/?api_key='+$scope.apikey;
        $http.post(url, converseRequest).then(
            function successCallback(response) {
                let code = response.status;
                if (code === 200) {
                        $scope.expertiseResponse = response.data.speech.text;
                        $scope.chosenExpertise = !response.data.skill ? 'None': response.data.skill.name;
                }
                else {
                    $scope.chosenExpertise = 'None.';
                    $scope.expertiseResponse = 'I didn\'t get that, please try again.'
                }
            }, function errorCallback(response) {
                let code = response.status;
                if (code === 401) {
                    $scope.errorMessage = "Not authorized";
                } else {
                    $scope.errorMessage = 'Error, code:' + code.toString();
                }
                $scope.chosenExpertise = 'None.';
                $scope.expertiseResponse = 'Error, code:' + code.toString();
            })
    };

    $scope.redirectToIAMLogin = function () {
        $window.location.href = '/iam-login';
    }

}

// module
var app = angular.module('ga-wpab', []);

app.config(function ($logProvider) {
    $logProvider.debugEnabled(false);
});

// directives
app.directive('main', [mainDirective]);

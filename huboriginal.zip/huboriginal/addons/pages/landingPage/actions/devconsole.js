import {FETCH_EXPERTISE_DATA, CONVERSE_CHAT} from './types';


export const fetchExpertiseData = (ApiKey) => {
  console.log("fetchExpertiseData action")
    return {
      type: 'FETCH_EXPERTISE_DATA',
      payload: ApiKey
   }
};

export const converseChat = (collectionName,input, ApiKey) => {
  console.log("fetch action chat",collectionName, input, ApiKey)

    return {
      type: 'CONVERSE_CHAT',
      collectionName: collectionName,
      input: input,
      ApiKey: ApiKey
   }
};

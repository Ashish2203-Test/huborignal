export default function devconsole(state = {}, action) {

  switch (action.type) {

    case 'FETCH_EXPERTISE_DATA':
  {
      return {data: action.ExpertiseData};
}
    default:
      return state;
  }
}

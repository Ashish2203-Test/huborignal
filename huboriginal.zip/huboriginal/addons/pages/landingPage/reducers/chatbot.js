export default function chatbot (state = {}, action) {

  switch (action.type) {

    case 'CONVERSE_CHAT':
    {
    return {dataChat: action.ConverseData};
}
    default:
      return state;
  }
}

import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";
import devconsole from "./devconsole";
import chatbot from "./chatbot";

export const reducers = combineReducers({
    routing: routerReducer,
    devconsoledata: devconsole,
    chatbot: chatbot
});

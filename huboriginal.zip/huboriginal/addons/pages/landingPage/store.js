import { createStore, applyMiddleware, compose } from "redux";
import { browserHistory } from "react-router";
import { syncHistoryWithStore, routerMiddleware } from "react-router-redux";
import freeze from "redux-freeze";
import createSagaMiddleware from "redux-saga";
import { reducers } from "./reducers/index";
import { sagas } from "./sagas/index";
import reduxThunk from 'redux-thunk';
import promise from 'redux-promise';
// add the middlewares
let middlewares = [];
//import { createBrowserHistory } from 'history';

console.log("IN THE STORE")

import createHistory from 'history/createBrowserHistory';

const history = createHistory();

// add the router middleware
middlewares.push(routerMiddleware(browserHistory));

// add the saga middleware
const sagaMiddleware = createSagaMiddleware();
middlewares.push(sagaMiddleware);
middlewares.push(reduxThunk);
middlewares.push(promise);

// add the freeze dev middleware
if (process.env.NODE_ENV !== 'production') {
  middlewares.push(freeze);
}

// apply the middleware
let middleware = applyMiddleware(...middlewares);

// add the redux dev tools
if (process.env.NODE_ENV !== 'production' && window.devToolsExtension) {
  middleware = compose(middleware, window.devToolsExtension());
}

// create the store
const store = createStore(reducers, middleware);
//const history = syncHistoryWithStore(browserHistory, store);
//const history = syncHistoryWithStore(createBrowserHistory(), store);
sagaMiddleware.run(sagas);

// export
export { store, history };

import React from 'react';
import ReactDOM from 'react-dom';
import Select from 'react-select';
import { connect } from 'react-redux';
import { converseChat } from '../actions/devconsole';
import { CONVERSE_CHAT } from '../actions/types';
import Waiting from './waiting.js'


class Chatbot extends React.Component{

  constructor() {
  super();
  this.state = {
  input: null,
   messages: [
   ],
   class:'hid'
};
this.handleInput = this.handleInput.bind(this);
  this.useConverse = this.useConverse.bind(this);
  this.enterValue = this.enterValue.bind(this);
  this.keyDown = this.keyDown.bind(this);
}


componentWillReceiveProps(props){
  const answer = props.data;
  const messages = this.state.messages;
    if(answer){
  let exInput=[];
  exInput.msg=answer;
  exInput.src='Expertise';
  messages.push(exInput);
    this.setState({class:'hid'});
}
else{
  this.setState({class:'vis'});
}
}


enterValue(e){
  e.preventDefault();
    this.setState({input:e.target.value});

}

handleInput(event) {
    this.setState({input:event.target.value});
}

keyDown(e){
  if(e.key == 'Enter'){
  console.log("VALLL",e.target.value);
  e.preventDefault();
  this.useConverse();

}
}


useConverse() {
  const collectionName = this.props.chatdata;
  const ApiKey = this.props.ApiKey;
  const input = this.state.input;
  let messages = this.state.messages;
  let UserInput=[];
  UserInput.msg=input;
  UserInput.src='user';

  messages.push(UserInput);
  this.setState({input:''});

  this.props.converseChat(collectionName,input, ApiKey);

  if(!collectionName){
    let exInput=[];
    exInput.msg='Select a skillset so that I know what you want to chat about.';
    exInput.src='Expertise';
    messages.push(exInput);
  }

}

	render(){
const messageList = this.state.messages;
console.log("messageList",messageList);

		return (
      <div className="chatbox">
      <span className="expertise"> Hello there! I&apos;m Watson</span>
      <div className="chatMessages">
      {messageList.map((option, index) =>
        <span className={option.src} >
         {option.msg}
        </span>
     )}
     </div>
     <div className="wait">
     </div>
     <div className="autosuggestbox">
     <div className="suggest">
     <button className="autosuggest" onClick={this.enterValue} value={"Hello"}>
              Hello
          </button>
          </div>
<div className="suggest">
          <button className="autosuggest" onClick={this.enterValue} value={"Goodbye"}>
                   Goodbye
               </button>
               </div>
 </div>
          <br></br>
          <div className="form-group has-feedback" >
              <input type="text" className="form-control chatInput" placeholder="Tap to Type..." onChange={this.handleInput} onKeyDown={this.keyDown} value={this.state.input}></input>
              <span onClick={this.useConverse}> <i className="glyphicon glyphicon-circle-arrow-up arrow-up"></i></span>
          </div>
          <div>
          </div>
          </div>
			)
	}
}

function mapStateToProps(state) {
  let result = null;
    if (state.chatbot.dataChat) {
      result = state.chatbot.dataChat.speech.text;
    }
    return {
      data: result,
    };

  }

export default connect(mapStateToProps, { converseChat })(Chatbot);

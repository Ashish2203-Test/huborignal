import React from 'react';
import ReactDOM from 'react-dom';
import Select from 'react-select';
import { connect } from 'react-redux';
import { fetchExpertiseData, getAvailableExpertise } from '../actions/devconsole';
import { FETCH_EXPERTISE_DATA, GET_AVAILABLE_EXPERTISE } from '../actions/types';
import Chatbot from './chatbot';
import _ from 'lodash';

class Devconsole extends React.Component{

componentDidMount() {
  let ApiKey = this.props.location.state.apikey;
 this.props.fetchExpertiseData(ApiKey);
}

  constructor(props, context) {
      super(props, context);
      this.state = {
      expertise: null
    };
    this.handleInput = this.handleInput.bind(this);
     }


   handleInput(event) {
this.setState({expertise : event.target.value});
   }

   render() {
     const collName = this.state.expertise;
     const  data  = this.props.data;
     let ApiKey = this.props.location.state.apikey;
     let expertises = [];
     let expertisesName = [];


if(data){
  _.forEach(data, function(obj,index) {
        if(obj.skillSet == collName){
           expertises = obj.skills;
           expertisesName = _.map(expertises, 'name');
         }
   });
}

       return (
           <div className="container-fluid mid">
               <div className="bx--global-header">
                   <div className="col-md-0.5 col-sm-0.5"> <img src="../../landingPage/Images/icon1.png" className="img"></img> </div>
                   <div className="col-md-4 col-sm-6"> <h1 className="bx--logo__text">IBM <span className="watson"><b>Watson</b></span> Assistant Console</h1></div>
                   <div className="col-md-6 col-sm-2"></div>
                   <div className="col-md-0.5 col-sm-1.5 bx--logo__text1"><a className="top-link link-text" href="https://watson-personal-assistant.github.io/developer/" rel="noreferrer" target="_blank">Docs</a></div>
                   <div className="col-md-1 col-sm-2 bx--logo__text1"><a className="top-link link-text"  href="https://github.com/Watson-Personal-Assistant/Beta-Support/issues" rel="noreferrer" target="_blank">Support</a></div>

               </div>


               {/*  Second Div containing Welcome to Beta and Chat Window */}
               <div className="row upper-background">
               <div className="background">
                   <div className="col-md-2 col-sm-1" ></div>
                   <form>
                   <div className="col-md-4 col-sm-5 p2">
                       <h1><label className="welcome"> Welcome to the Beta!</label></h1>
                       <p className="info">Skills are combined within a skillset to create intuitive Personal Assistants. The section below contains skillsets that are already available for you to chat with.</p>
                       <br></br>
                       <p className="info"> Pick a skillset of skills from the list and start chatting with it!</p>
                       <div>
                       <div className="dropdown col-sm-6 dropdowna">
                       <select onChange={this.handleInput} value={this.state.expertise} defaultValue="Select" className="select-box">
                       <option>Built-in Skillset</option>
                            {data.map((option, index) =>
                              <option key={index} value={option.skillSet} >
                               {option.skillSet}
                              </option>

                           )}
                         </select>
                         </div>
                      <u className="underline add-collection col-sm-6"><div className="info1"></div></u>
                       </div>
                       <textarea className="textarea" rows="6" cols="42" value={expertisesName}>

                     </textarea>
                   </div>

                   <div className="col-md-4 col-sm-5 p2">
                      <Chatbot chatdata={this.state.expertise} ApiKey={this.props.location.state.apikey}/>

                   </div>
                   </form>
                   <div className="col-md-2 col-sm-1">
                   </div>
                   </div>
               </div>

               {/* Third Div containing Step By Step Instruction Line*/}
               <div className="row mid background2">
                   <div className="col-md-2 col-sm-1" ></div>
                   <div className="col-md-4 col-sm-5 image">
                       <img src="../../landingPage/Images/console-docs.png" className="image"></img>
                   </div>
                   <div className="col-sm-4">
                       <h2 className="h2"> Step-by-step instructions </h2>
                       <br></br>
                       <p className="instructions">Whatever type of application you are building, be it mobile, web or an integrated
                       hardware and software solution, you will need to understand how your user will communicate with that device of choice. Follow
                       the step-by-step docs to complete this process.</p>
                       <br></br>
                       <br></br>
                       <button type="button" className="btn btn-inverse btnread"><a className="readdoc" href="https://watson-personal-assistant.github.io/developer/get-started/get-started/" rel="noreferrer" target="_blank">Read the Docs</a></button>
                   </div>
                   <div className="col-md-2 col-sm-1">
                   </div>
               </div>


               {/*  Fourth Div Containing Build Applications with Watson Personal Assistant Builder APIs*/}
               <div className="row">
                   <div className="col-md-2 col-sm-1" ></div>
                   <div className="col-md-8 col-sm-10 p4">
                       <br></br>
                       <br></br>

                       <h2 className="build">Build Applications with</h2>
                       <h2 className="build"> Watson Assistant Builder APIs</h2>
                       <br></br>
                       <p className="build1">The Watson Assistant Builder service allows developers to quickly design, build, test, deploy, and run Personal Assistant applications.</p>

                   </div>
                   <div className="col-md-2 col-sm-1">
                   </div>
               </div>


                {/*  Fifth Div containing WPA Builder API,WPA Builder Knowledge and Reasoning,Logs,WPA Agents*/}
               <div className="row background3">
                   <div className="col-md-2 col-sm-1" ></div>
                   <div className="col-md-4 col-sm-5 p3">
                       <img src="../../landingPage/Images/console-WPAbuilderapi.png" className="smallimg"></img>
                       <a href={'/docs/?api_key='+ApiKey} className="link-builder" target="_blank" rel="noreferrer">Conversation API</a>
                       <br></br>
                       <p className="paralink" >
                       Use the Swagger API to complete the following tasks:
                       </p>
                       <ul className="api-lists paralink">
                       <li>Converse and organize skill.</li>
                       <li>Route requests to the correct skill.</li>
                       <li>Register skill publicly.</li>
                       <li>Verify the health of skill.</li>
                       <li>View the <a href={'/logs/?api_key='+ApiKey} target="_blank" rel="noreferrer">Conversation Logs</a>.</li>
                       </ul>

                       <br></br>
                       <br></br>
                       <img src="../../landingPage/Images/console-logs.png" className="smallimg"></img>

                       <a className="link-builder" target="_blank" href={'/context/docs/?api_key='+ApiKey} rel="noreferrer">Context API</a>
                       <br></br>
                       <p className="paralink" >Use the Swagger API to modify the context of the skills information that is stored.
                       Two options are provides: one user per skill or one user across all skills.</p>


                   </div>
                   <div className="col-md-4 col-sm-5 p3">

                       <img src="../../landingPage/Images/console-WPAknr.png" className="smallimg"></img>

                       <a href={'knowledge/apidocs/?api_key='+ApiKey} className="link-builder" target="_blank" rel="noreferrer">Knowledge API</a>
                       <br></br>
                       <p className="paralink" >
                       Use the Swagger API to complete the following tasks:</p>
                       <ul className="api-lists paralink">
                       <li>Create a shared data object storage service to store object models.</li>
                       <li>Create a shared message queue service that allows agents to publish and subscribe to events, such as object state changes.</li>
                       </ul>
                       <br></br>
                       <br></br>
                       <img src="../../landingPage/Images/console-wpaagents.png" className="smallimg"></img>

                       <a href={'/agent/apidocs/?api_key='+ApiKey} className="link-builder" target="_blank" rel="noreferrer">Rules API</a>
                       <br></br>
                       <p className="paralink" >Use the Swagger API to create and subscribe agents to the Watson Assistant Builder services.</p>

                   </div>
                   <div className="col-md-2 col-sm-1">
                   </div>
               </div>

               {/* Sixth Div Containing Embed Watson Personal Assistant into Devices */}

               <div className="row">
               <div className="background4">
                   <div className="col-md-2 col-sm-1"  ></div>
                   <div className="col-md-4 col-sm-5 p3ext"  >

                       <h1 className="underline">Embed Watson Assistant into Slack</h1>
                       <br></br>
                       <p className="underline1">Watson Assistant Builder allows a developer to add proactive, interactive experiences into Slack.</p>
                       <br></br>
                       <button type="button" className="btn btn-inverse btntutorial"><a className="top-link link-text tut-link" href="http://ibm.biz/BdjwyS"
                        target="_blank" rel="noreferrer">View Tutorial</a></button>
                   </div>
                   <div className="col-md-4 col-sm-5 p3ext"  >
                       <div className="videoUiWrapper thumbnail">

                               <img src="../../landingPage/Images/slack.png" width="300" height="274">

                               </img>
                       </div>
                   </div>
                   <div className="col-md-2 col-sm-1"  >
                   </div>
               </div>
               </div>

              {/* Seventh Div containing CopyRights */}

               <div className="row mid">
               <div className="col-sm-1 col-md-1"></div>
                   <div className="col-sm-2 col-md-2" >
                       <p className="copyr">Copyright © 2017 IBM</p>
                   </div>
                   <div className="col-sm-3 col-md-3" >
                       <label className="Condition"><a href="https://watson-personal-assistant.github.io/developer/legal/terms-of-use/" target="_blank" className="termsConditions" rel="noreferrer">Beta Terms and Conditions</a></label>
                   </div>
                   <div className="col-sm-4 col-md-4 p2">
                   </div>
                   <div className="col-sm-2 col-md-2">
                       <button type="button" className="btn btn-inverse btntutorial1"><a className="feedback link-text" href="https://www.surveygizmo.com/s3/3974701/Watson-Assistant-NPS" target="_blank" rel="noreferrer">Submit Feedback  <span className="caret"></span></a></button>
                   </div>
               </div>


           </div>


       );
   }
}

function mapStateToProps(state) {
console.log("STATE OF DEVCONSOLE",state)
let result = [];
let expertises = [];
  if (state.devconsoledata.data) {
    result = state.devconsoledata.data;
  }
  return {
    data: result,
  };
}

export default connect(mapStateToProps, { fetchExpertiseData ,getAvailableExpertise })(Devconsole);

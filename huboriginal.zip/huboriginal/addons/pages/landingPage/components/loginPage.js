import React from 'react';
import ReactDOM from 'react-dom';
import Devconsole from './devconsole.js'
import { connect } from 'react-redux';
import { store } from "../store.js";
import { Router, Route, IndexRoute, withRouter } from "react-router";
{/*Login Page Component*/}


class loginPage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            apikey: '',
            isIAMEnabled : false
        }
        this.getConfig = this.getConfig.bind(this);
     }

     componentDidMount(){
           this.getConfig();
     }

    handleInput (event) {
        var state = this.state;
        state.apikey = event.target.value;
        state.authorized = true;
        state.errorMessage = "";
        this.setState(state);
    }

    getConfig() {
      return new Promise((resolve, reject) => {
        fetch('/config/')
          .then(function(response) {
            this.state.isIAMEnabled = response.data.iamEnabled;
          })
          .catch(err => {
            this.state.isIAMEnabled = false;
          });
      });
    }

handleKeyDown (event) {
  if(event.key == 'Enter'){
    event.preventDefault()
    this.verifyKey();
  }
}

    verifyKey() {
      let apiKey = this.state.apikey;

        // Call the API page
        fetch('/validateKey/' + this.state.apikey)
        .then((result) => {
            console.log("result ", result);
            console.log("result ", result.response);
            console.log("result ", result.status);
            var code = result.status;
            if (code === 200) {
                var state = this.state;
                state.authorized = true;
                state.errorMessage = "";
                this.setState(state);
              this.props.history.push({
                  pathname: '/dev-console',
                  state: { apikey: apiKey }
                })
            } else
            if (code === 401) {
                var state = this.state;
                state.authorized = false;
                state.errorMessage = "KEY NOT FOUND";
                this.setState(state);
            } else {
                var state = this.state;
                state.authorized = false;
                state.errorMessage = "Unknown error";
                this.setState(state);
            }
        });

    }

    render(){
          let errorMsg = this.state.errorMessage;
          let inputButton;

          if(errorMsg){
            inputButton = <input type="string" name="inputBox" value={this.state.value} onChange={this.handleInput.bind(this)} onKeyDown={this.handleKeyDown.bind(this)} className="form-control new-class c goterror" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx"></input>
          }
          else{
            inputButton = <input type="string" name="inputBox" value={this.state.value} onChange={this.handleInput.bind(this)} onKeyDown={this.handleKeyDown.bind(this)} className="form-control new-class c" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxx"></input>
          }

            return (
             <div className="container-fluid c">
              {/*Entire webPage is divided into 2-8-2 columns (Bootstrap Concept)*/}
                 <div className="row">
                     {/*First two columns are empty*/}
                     <div className="col-md-2 col-sm-1 c"></div>

                     {/*center part of page (Login div)*/}
                     <div className="col-sm-10 col-md-8 c">
                             {/*Half of center is allocated to display image*/}
                             <div className="col-sm-6 c login-left">
                                 <img src = "./landingPage/Images/api-login.png" className="loginimage c"></img>
                             </div>
                              {/*Half of center is allocated to display login functionality*/}
                             <div className="col-sm-6 c login-right">
                                 <h1><label className="H1 c">Watson Assistant Console</label></h1>
                                 <p><label className="p c">Login with your API key and gain access to your instance of WPA</label></p>
                                  {/*Actual login form*/}

                                     <div className="login-apikey">
                                         {inputButton}
                                         <input type="button" className="btn btn-default c loginwithapi" onClick={this.verifyKey.bind(this)} value="Login"/>

                                         <span className="errorMsg">
                                         {this.state.errorMessage}
                                         </span>
                                         
                                     </div>
                             </div>
                     </div>
                     {/*Last two columns are empty*/}
                     <div className="col-md-2 col-sm-1 c"></div>
                 </div>
             </div>
            );
        }
 }

 function mapStateToProps(state) {

 }

 export default connect(null, {})(loginPage);

/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var bl = require("sagan-dev-node-sdk").bl;

exports.validateKey = {
    'spec': {
        path: "/core/validateKey/{apikey}",
        method: "get",
        noValidation: true,
        summary: "check if user is authorized",
        description: "check if user is authorized",
        responseMessages: [],
        parameters: [{
            "in": "path",
            "name": "apikey",
            "paramType": "path",
            "type": "string",
            "description": "apikey",
            "required": true
        }],
        type: "GeneralResult",
        nickname: "validateKey",
        produces: ["application/json"]
    },
    'action': function (req, res) {
        var body = req.params;
        var apikey = body.apikey;

        bl.route.validateKey(apikey, function (err, core) {
            if (err) {
                res.send(401);
            } else {
                res.send(200);

            }
        });
    }
};

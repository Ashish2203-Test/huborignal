let db = require('../../dao');

let insertApiActivityRecordForApiKey = function (key, url, status) {
    if (!ignoreUrl(url)) {
        let query = "INSERT into SAGAN.SAGAN_API_ACTIVITY (URL, STATUS, CLIENT_ID) VALUES (?, ?, (SELECT id FROM SAGAN.SAGAN_CLIENTS WHERE CLIENT_API_KEY = ?))";
        let params = [url, status, key];
        db.insert(query, params).then(function (resp) {
            if (resp) {
                console.log('insertApiActivityRecord, Activity record inserted');
            } else {
                console.log('insertApiActivityRecord, Error while inserting Activity record');
            }
        });
    }
};

/**
 * Insert new activity record for iam user access token based authz
 * @param core
 * @param url
 * @param status
 */
let insertApiActivityRecordForIAM = function (core, url, status) {
    if (!ignoreUrl(url)) {
        let query = "INSERT into SAGAN.SAGAN_API_ACTIVITY (URL, STATUS, CLIENT_ID, BMX_ID) VALUES (?, ?, (SELECT id FROM SAGAN.SAGAN_CLIENTS WHERE CLIENT_ID = ?), ?)";
        let params = [url, status, core.clientID, core.bmxId];

        // console.log('query = ' + query);
        // console.log('params = ' + JSON.stringify(params));

        db.insert(query, params).then(function (resp) {
            if (!resp) {
                console.error('insertApiActivityRecord, Error while inserting Activity record for bmx_id ', core.bmxId);
            }
        });
    }
};

let ignorePatterns = ['.png', '.css', '.js', '.ico', '.jpg', '.gif'];
let ignoreUrl = function (url) {
    if(url.indexOf('exclude_tracking=true') != -1){
        return true;
    }
    for (let i = 0; i < ignorePatterns.length; i++) {
        if (url.endsWith(ignorePatterns[i])) {
            return true;
        }
    }

    return false;
};

module.exports.insertApiActivityRecordForApiKey = insertApiActivityRecordForApiKey;
module.exports.insertApiActivityRecordForIAM = insertApiActivityRecordForIAM;

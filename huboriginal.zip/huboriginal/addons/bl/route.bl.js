/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var basebl = require('sagan-dev-node-sdk').bl.base;
var BASE = new basebl('route');
const uuidv4 = require('uuid/v4');
let redis = require('../../cache');

db = BASE;

db.validateKey = function (apiKey, callback) {
    redis.getObject(apiKey, function(err, data) {
        if (err) {
            console.log('Error while searching in redis: ', apiKey);
        }

        if (data) {
            return callback(data);
        }

        var self = db;
        self.getAllByAttribute("apikey", apiKey, function (err, results) {
            if (err) {
                console.log("Error getting the api key " + err);
                callback(null);
            } else if (results.length !== 1) {
                console.log("got zero or too many results: " + results.length);
                callback(null);
            } else {
                redis.putObject(apiKey, results[0], 600);
                callback(results[0]);
            }
        });
    });
};

db.addNewRoute = function(clientName, callback) {
    var self = db;

    self.countAll(function(err, cnt) {
        if (err) {
            callback(err, null);
        } else {
            var count = cnt + 1;
            var uuid = uuidv4();
            var uuidName = uuidv4();

            var newCore = {};
            newCore.apikey = uuid;
            newCore.clientName = clientName;
            newCore.clientID = uuidName;
            newCore.coreUrl = "saganCore" + count + "-" + clientName + "-" + uuidName +".mybluemix.net";
            newCore.persistentData = {};

            self.insert(newCore, function(err2, result) {
                if (err2) {
                    callback(err2, null);
                } else {
                    callback(null, newCore);
                }
            })
        }
    })
};

db.getClientRecFromClientId = function(clientId, callback) {
    var self = db;
    let redisKey = clientId;

    redis.getObject(redisKey, function(err, data) {
        if (err) {
            console.log('Error while searching clientId in redis: ', redisKey);
        }

        if (data) {
            return callback(data);
        }

        self.getAllByAttribute("clientID", clientId, function (err, results) {
            if (err) {
                console.log("Error getting record by client Id, " + err);
                callback(null);
            } else if (results.length !== 1) {
                console.log("Got zero or too many results, " + results.length);
                callback(null);
            } else {
                redis.putObject(clientId, results[0], 3600);
                callback(results[0]);
            }
        });
    });
};

module.exports = db;

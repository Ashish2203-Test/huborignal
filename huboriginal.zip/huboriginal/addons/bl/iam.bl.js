/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var basebl = require('sagan-dev-node-sdk').bl.base;
var BASE = new basebl('iam');
let redis = require('../../cache');
let db = BASE;

db.validateIAMId = function(iamId, callback) {
    var self = db;
    let key = iamId + "_access_rec";
    console.log('Getting client record from cache for key, ', key);

    redis.getObject(key, function(err, data) {
        if (err) {
            console.log('Error while searching iamId in redis for key, ', iamId);
        }

        if (data) {
            return callback(data);
        }

        self.getByView(iamId, "IAMView", "searchByIAMId", true, function (err, results) {
            if (err) {
                console.log("Error getting user name " + err);
                return callback(null);
            } else if (results.length !== 1) {
                console.log("Got zero or too many results: " + results.length);
                return callback(null);
            } else {
                redis.putObject(key, results[0], 120);
                return callback(results[0]);
            }
        });
    });
};

db.validateBMXId = function(bmxId, callback) {
    var self = db;
    let key = bmxId + "_access_rec";
    console.log('Getting client record from cache for key, ', key);

    redis.getObject(key, function(err, data) {
        if (err) {
            console.log('Error while searching bmxId in redis: ', bmxId);
        }

        if (data) {
            return callback(data);
        }

        console.log('Calling getByView to get client record');
        self.getByView(bmxId, "IAMView", "searchByBMXId", true, function (err, results) {
            if (err) {
                console.log("Error searching bmxId:" + err);
                return callback(null);
            } else if (results.length !== 1) {
                console.log("Got zero or too many results: " + results.length);
                return callback(null);
            } else {
                redis.putObject(key, results[0], 120);
                return callback(results[0]);
            }
        });
    });
};

db.findAccessRecord = function(clientId, iamId, callback) {
    var self = db;
    let key = iamId + "_access_rec";
    let searchKey = iamId;
    let viewName = 'searchByIAMId';

    if (clientId) {
        key = clientId + '_' + key;
        searchKey = [[iamId, clientId]];
        viewName = 'searchByIAMIdAndClientId';
    }

    console.log('Getting access record from cache for key, ' + key);
    redis.getObject(key, function(err, data) {
        if (err) {
            console.error('Error while searching iamId in redis = ' + iamId);
        }

        if (data) {
            // console.log('Found access record in cache = ' + JSON.stringify(data));
            return callback(null, data);
        }

        console.log('Calling getByView to get client record, viewName = ' + viewName + ', searchkey = ' + JSON.stringify(searchKey));
        self.getByView(searchKey, "IAMView", viewName, true, function (err, results) {
            if (err) {
                console.log("Error searching record," + err);
                return callback(err, null);
            } else if (results.length !== 1) {
                console.log("Got zero or too many results: " + results.length);
                return callback(null, null);
            } else {
                redis.putObject(key, results[0], 300);
                return callback(null, results[0]);
            }
        });
    });
};

db.addNewAccessRecord = function(clientId, iamId, bmxId, callback) {
    var self = db;
    this.findAccessRecord(clientId, iamId, function(err, rec) {
        if (err) {
            return callback(err, null);
        }

        if (rec) {
            return callback('Access already granted', null);
        } else {
            var newAccessRecord = {};
            newAccessRecord.clientId = clientId;
            newAccessRecord.iamId = iamId;
            newAccessRecord.bmxId = bmxId;

            self.insert(newAccessRecord, function(err2, result) {
                if (err2) {
                    callback(err2, null);
                } else {
                    callback(null, newAccessRecord);
                }
            })

        }
    });

};

db.deleteAccessRecord = function(doc, callback) {
    return db.delete(doc, callback);
};

module.exports = db;

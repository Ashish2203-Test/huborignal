/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

let basebl = require('sagan-dev-node-sdk').bl.base;
let BASE = new basebl('configuration');
const async = require('async');

let db = BASE;

const AVATAR = "avatar";
const EXPERTISE = "expertise";
const REGISTRY = "registry";
const LINK = "link";
const CLIENT_KEY = "clientID";

//////////////////////
// base functions   // maybe extract this to a parent class?
//////////////////////

db.getAllClientConfiguration = function (clientID, callback) {
    let self = db;
    self.getAllByAttribute(CLIENT_KEY, clientID, function (err, results) {
        if (err) {
            console.log("Problem fetching client's data - " + err);
            callback(null);
        } else {
            callback(returnOnlyData(results));
        }
    })
};

let copyData = function (target, source) {
    let keys = Object.keys(source);

    keys.forEach(function (key) {
        target[key] = source[key];
    });
};

let returnOnlyData = function (oldArray) {
    let newArray = [];

    oldArray.forEach(function (item) {
        newArray.push(item.data);
    });

    return (newArray);
};

let getAllClientEntites = function (clientID, entityType, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    self.dal.select(query, function (err, results) {
        if (err) {
            console.log("Problem fetching client's data - " + err);
            callback(null);
        } else {
            callback(returnOnlyData(results));
        }
    });
};

let getClientEntityByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            console.log("Problem fetching client's data - " + err);
            callback(null);
        } else {
            callback(results[0]);
        }
    });
};

let getClientEntityByKeyValue = function (clientID, entityType, key, value, callback) {
    getClientEntityByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let getAllClientEntitiesByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            console.log("Problem fetching client's data - " + err);
            callback(null);
        } else {
            callback(results);
        }
    });
};

let getAllClientEntitiesByKeyValue = function (clientID, entityType, key, value, callback) {
    getAllClientEntitiesByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let insertClientEntity = function (clientID, entityType, data, callback) {
    let self = db;

    let newDoc = {};
    newDoc.clientID = clientID;
    newDoc.type = entityType;
    newDoc.data = data;

    self.insert(newDoc, callback);
};


//////////////////////
// Avatar functions // maybe extract this to a child class?
//////////////////////

db.getAllClientAvatars = function (clientID, callback) {
    getAllClientEntites(clientID, AVATAR, callback);
};

// This is for "external" calls
db.getClientAvatarByName = function (clientID, avatarName, callback) {
    getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (avatar) {
        callback(avatar ? avatar.data : null);
    });
};

db.insertClientAvatar = function (clientID, data, callback) {
    insertClientEntity(clientID, AVATAR, data, callback)
};

db.updateClientAvatarByName = function (clientID, avatarName, data, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (result) {
        if (!result) {
            console.log("Problem fetching client's data");
        } else {
            copyData(result, data);
            self.update(result, callback);
        }
    })
};

db.deleteClientAvatarByName = function (clientID, avatarName, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (avatar) {
        if (!avatar) {
            console.log("Problem fetching client's data");
            callback(null);
        } else {
            self.delete(avatar, function (err, deleteResult) {
                if (err) {
                    callback(null);
                } else {
                    callback(avatar.data);
                }
            });
        }
    })
};


//////////////////////
// Expertise functions // maybe extract this to a child class?
//////////////////////

db.getAllClientExpertise = function (clientID, callback) {
    getAllClientEntites(clientID, EXPERTISE, callback);
};

// This is for "external" calls
db.getClientExpertiseByName = function (clientID, expertiseName, callback) {
    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (expertise) {
        callback(expertise ? expertise.data : null);
    });
};

db.insertClientExpertise = function (clientID, data, callback) {
    insertClientEntity(clientID, EXPERTISE, data, callback)
};

db.updateClientExpertiseByName = function (clientID, expertiseName, data, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (result) {
        if (!result) {
            console.log("Problem fetching client's data");
            callback(null);
        } else {
            copyData(result, data);
            self.update(result, callback);
        }
    })
};

db.deleteClientExpertiseByName = function (clientID, expertiseName, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (result) {
        if (!result) {
            console.log("Problem fetching client's data");
            callback(null);
        } else {
            self.delete(result, callback);
        }
    })
};


////////////////////////
// Registry functions // maybe extract this to a child class?
////////////////////////

db.getAllClientRegistry = function (clientID, callback) {
    getAllClientEntites(clientID, REGISTRY, callback);
};

// This is for "external" calls
db.getClientRegistryByName = function (clientID, expertiseName, callback) {
    getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (expertise) {
        callback(expertise ? expertise.data : null);
    });
};

db.insertClientRegistry = function (clientID, data, callback) {
    insertClientEntity(clientID, REGISTRY, data, callback)
};

db.updateClientRegistryByName = function (clientID, expertiseName, data, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (expertise) {
        if (!expertise) {
            console.log("Problem fetching client's data");
            callback(expertise, null);
        } else {
            copyData(expertise.data, data);
            self.update(expertise, callback);
        }
    })
};

db.deleteClientRegistryByName = function (clientID, expertiseName, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (Registry) {
        if (!Registry) {
            console.log("Problem fetching client's data");
            callback("Problem fetching client's data", null);
        } else {
            self.delete(Registry, callback);
        }
    })
};


////////////////////////
//   Link functions   // maybe extract this to a child class?
////////////////////////

db.getAllClientLinks = function (clientID, callback) {
    getAllClientEntites(clientID, LINK, callback);
};


let getClientLinkByExpertiseAndAvatarNamesRaw = function (clientID, expertiseName, avatarName, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: avatarName
    });

    pairsArray.push({
        key: "expertise.name",
        value: expertiseName
    });

    getClientEntityByKeyValueArray(clientID, LINK, pairsArray, function (link) {
        callback(link ? link : null);
    });
};

// This is for "external" calls
db.getClientLinkByExpertiseAndAvatarNames = function (clientID, expertiseName, avatarName, callback) {

    getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
        callback(link ? link.data : null);
    });
};

db.getClientExpertiseNamesByAvatar = function (clientID, avatarName, fallback, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: avatarName
    });

    if (fallback !== undefined) {
        pairsArray.push({
            key: "expertise.fallback",
            value: fallback
        });
    }

    getAllClientEntitiesByKeyValueArray(clientID, LINK, pairsArray, function (links) {
        let names = [];

        links.forEach(function (link) {
            names.push(link.data.expertise.name);
        });

        callback(names);
    });
};

db.getClientAvatarsNamesByExpertise = function (clientID, expertiseName, callback) {

    getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", expertiseName, function (links) {
        let names = [];

        links.forEach(function (link) {
            names.push(link.data.expertise.name);
        });

        callback(names);
    });
};

db.insertClientLink = function (clientID, data, callback) {
    insertClientEntity(clientID, LINK, data, callback)
};

db.updateClientLinkByExpertiseAndAvatarNames = function (clientID, expertiseName, avatarName, data, callback) {
    let self = db;

    getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
        if (!link) {
            console.log("Problem fetching client's data");
            callback(link, null);
        } else {
            copyData(link, data);
            self.update(link, callback);
        }
    })
};

db.deleteClientLinkByExpertiseAndOrAvatarNames = function (clientID, expertiseName, avatarName, callback) {
    let self = db;

    if (avatarName && expertiseName) {
        getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
            if (!link) {
                console.log("Problem fetching client's data");
                callback("Problem fetching client's data", link);
            } else {
                self.delete(link, function (err, result) {
                    callback(err, returnOnlyData([link]));
                });
            }
        })
    } else if (!avatarName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", expertiseName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    } else if (!expertiseName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "avatar", avatarName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    }
};


module.exports = db;


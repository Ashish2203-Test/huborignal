/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var basebl = require('sagan-dev-node-sdk').bl.base;
var BASE = new basebl('core');
const uuidv4 = require('uuid/v4');

db = BASE;

db.validateKey = function (apiKey, callback) {
    var self = db;
    self.getAllByAttribute("apikey", apiKey, function (err, results) {
        if (err) {
            console.log("Error getting the api key " + err);
            callback(null);
        } else if (results.length !== 1) {
            console.log("got zero or too many results: " + results.length);
            callback(null);
        } else {
            callback(results[0]);
        }
    });
};

db.addNewCore = function(clientName, callback) {
    var self = db;

    self.getAll(function(err, results) {
        if (err) {
            callback(err, null);
        } else {
            var count = results.length;
            var uuid = uuidv4();
            var uuidName = uuidv4();

            var newCore = {};
            newCore.apikey = uuid;
            newCore.clientName = clientName;
            newCore.clientGuid = uuidName;
            newCore.coreUrl = "saganCore" + count + "-" + clientName + "-" + uuidName +".mybluemix.net";
            newCore.persistentData = {};

            self.insert(newCore, function(err2, result) {
                if (err2) {
                    callback(err2, null);
                } else {
                    callback(null, newCore);
                }
            })
        }
    })
};

module.exports = db;


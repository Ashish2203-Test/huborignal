/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var basedal = require('sagan-dev-node-sdk').basedal;
module.exports = new basedal("routes");

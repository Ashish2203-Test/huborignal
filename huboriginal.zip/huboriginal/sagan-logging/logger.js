'use strict';
const loggingClient = require('./lib');
let exec = require('child_process').exec;

let appName;
let appGuid;
let spaceGuid;
let consoleLoggingOnly = false;

let env = process.env.BMX_ENV;

function getAppInfo(callback) {

  console.log(process.env);
  if (process && process.env && process.env.VCAP_APPLICATION) {
    let spaceGuid = JSON.parse(process.env.VCAP_APPLICATION).space_id;
    let appGuid = JSON.parse(process.env.VCAP_APPLICATION).application_id;
    let appName = JSON.parse(process.env.VCAP_APPLICATION).application_name;

    callback({
      spaceGuid: spaceGuid,
      appGuid: appGuid,
      appName: appName
    });
  } else if (process.env.WF_DEPLOY_TARGET !== "local") {
    exec("cf env " + process.env.WF_DEPLOY_DIRECT_TARGET_PREFIX, function (error, stdout, stderr) {
      if (error) {
        callback({});
      } else {
        let indexSpaceID = stdout.indexOf("space_id");
        let spaceGuid = stdout.substr(indexSpaceID + 12, 36);
        console.log('spaceGuid = ' + spaceGuid);

        let indexAppID = stdout.indexOf("application_id");
        let appGuid = stdout.substr(indexAppID + 18, 36);
        console.log('appGuid = ' + appGuid);

        let indexAppName = stdout.indexOf("application_name");
        let indexAppNameEnd = stdout.indexOf('",', indexAppName + 20);
        let appName = stdout.substr(indexAppName + 20, (indexAppNameEnd - indexAppName - 21));
        console.log('appName = ' + appName);

        callback({
          spaceGuid: spaceGuid,
          appGuid: appGuid,
          appName: appName
        });
      }
    });
  } else {
    consoleLoggingOnly = false;
    callback({});
  }
}

function init(env) {
  getAppInfo(function (info) {
    if (info.appGuid) {
      appGuid = info.appGuid;
    }

    if (info.spaceGuid) {
      spaceGuid = info.spaceGuid;
    }

    if (info.appName) {
      appName = info.appName;
    }
  });

  if (env) {
    loggingClient.init(env);
  }
}

function logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, logLevel) {
  if (!messsage) {
    return;
  }

  let message = new Map();
  let console = '';

  message.set('logLevel', logLevel);
  console += logLevel;

  if (appName) {
    message.set('app_name', appName);
    console += ', app= ' + appName;
  }

  if (methodName) {
    message.set('method', methodName);
    console += ', method= ' + methodName;
  }

  if (clientId) {
    message.set('clientId', clientId);
    console += ', client= ' + clientId;
  }

  if (requestId) {
    message.set('requestId', requestId);
    console += ', requestId= ' + requestId;
  }

  if (userId) {
    message.set('userId', userId);
    console += ', userId= ' + userId;
  }

  message.set('message', messsage);
  console += ', message= ' + messsage;

  if (custom) {
    let keys = Object.keys(custom);
    if (keys && keys.length > 0) {
      message.set(key, custom[key]);
    }

    console += ', custom= ' + JSON.stringify(custom);
  }

  if (appGuid) {
    message.set('application_id', appGuid);
  }

  if (consoleLoggingOnly) {
    // console.log(console);
  } else {
    loggingClient.sendLogRecord(message);
    if (forCustomer) {
      loggingClient.sendLogRecordToClient(message);
    }
  }
}

function info(methodName, clientId, requestId, userId, messsage, custom, forCustomer) {
  logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, 'INFO');
}

function error(methodName, clientId, requestId, userId, messsage, custom, forCustomer) {
  logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, 'ERR');
}

function debug(methodName, clientId, requestId, userId, messsage, custom, forCustomer) {
  logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, 'DEBUG');
}

function silly(methodName, clientId, requestId, userId, messsage, custom, forCustomer) {
  logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, 'SILLY');
}

function warn(methodName, clientId, requestId, userId, messsage, custom, forCustomer) {
  logMessage(methodName, clientId, requestId, userId, messsage, custom, forCustomer, 'WARN');
}

module.exports = {
  init: init,
  info: info,
  error: error,
  debug: debug,
  silly: silly,
  warn: warn
};

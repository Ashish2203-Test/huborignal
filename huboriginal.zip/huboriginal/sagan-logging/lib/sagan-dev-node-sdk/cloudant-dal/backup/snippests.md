
First login to target organization and space

In this case

  - org: *hrlbmix@us.ibm.com*
  - space: *Iot4i-dev*


## How to start a replication
- The database source and target are the `url` attribute , from the **credentials** tab of the service instance
- see [Cloudant API](https://docs.cloudant.com/replication_guide.html#how-do-i-run-replication-across-different-cloudant-accounts?)
- see [Cloudant Advanced](https://docs.cloudant.com/advanced_replication.html)

Command Issued:
```sh
SOURCE_DB=https://04ed5b38-f595-44e9-b875-031ed3423e71-bluemix:3d4cda975fbdc54cc441020f0fe5d52b6daed60ff7c9fd0aba2075fe85927168@04ed5b38-f595-44e9-b875-031ed3423e71-bluemix.cloudant.com \
TARGET_DB=https://427af75d-df61-496c-9a54-2c66ff87858d-bluemix:a8257e322fe0bfd6d95f97e7d83543489e03c50dcc2dd08952bd3625403e2b25@427af75d-df61-496c-9a54-2c66ff87858d-bluemix.cloudant.com \
$(curl -X POST -H 'Content-Type:application/json' \
   -d "{ \
   \"_id\":\"AviadWeekly02\",\"source\": \"$SOURCE_DB/promotions\", \
   \"target\": \"$TARGET_DB/promotions\", \
   \"create_target\": true \
   }" \
   $SOURCE_DB/_replicator)
```
Result:
```sh
{"ok":true,"id":"AviadWeekly02","rev":"1-ce0dde99a82794a32a5505e7bf8af17a"}
```

## How to start a *Continous* replication
Command Issued:
```sh
SOURCE_DB=https://04ed5b38-f595-44e9-b875-031ed3423e71-bluemix:3d4cda975fbdc54cc441020f0fe5d52b6daed60ff7c9fd0aba2075fe85927168@04ed5b38-f595-44e9-b875-031ed3423e71-bluemix.cloudant.com \
TARGET_DB=https://427af75d-df61-496c-9a54-2c66ff87858d-bluemix:a8257e322fe0bfd6d95f97e7d83543489e03c50dcc2dd08952bd3625403e2b25@427af75d-df61-496c-9a54-2c66ff87858d-bluemix.cloudant.com \
$(curl -X POST -H 'Content-Type:application/json' \
   -d "{ \
   \"_id\":\"AviadWeekly04\",\"source\": \"$SOURCE_DB/promotions\", \
   \"target\": \"$TARGET_DB/promotions\", \
   \"create_target\": true, \
   \"continuous\": true \
   }" \
   $SOURCE_DB/_replicator)
```
Result:
```sh
  {"ok":true,"id":"AviadWeekly04","rev":"1-b4ed4602ca0de01609f79fa4cdcabab8"}
```

or
```sh
SOURCE_DB=https://04ed5b38-f595-44e9-b875-031ed3423e71-bluemix:3d4cda975fbdc54cc441020f0fe5d52b6daed60ff7c9fd0aba2075fe85927168@04ed5b38-f595-44e9-b875-031ed3423e71-bluemix.cloudant.com \
TARGET_DB=https://427af75d-df61-496c-9a54-2c66ff87858d-bluemix:a8257e322fe0bfd6d95f97e7d83543489e03c50dcc2dd08952bd3625403e2b25@427af75d-df61-496c-9a54-2c66ff87858d-bluemix.cloudant.com \
; curl -X POST -v \
 -H 'Content-Type:application/json' \
 "$SOURCE_DB/_replicator" \
 -d @<(cat <<EOF

 {
   "_id": "weekly_backup",
   "source": "$SOURCE_DB/shields",
   "target": "$TARGET_DB/shields",
   "create_target": true
 }
 EOF
 )  
```



## Monitor a replication
Command Issued:
```sh
SOURCE_DB=https://04ed5b38-f595-44e9-b875-031ed3423e71-bluemix:3d4cda975fbdc54cc441020f0fe5d52b6daed60ff7c9fd0aba2075fe85927168@04ed5b38-f595-44e9-b875-031ed3423e71-bluemix.cloudant.com ; \
curl $SOURCE_DB/_replicator/AviadWeekly04
```

Result:
```sh
 {"_id":"AviadWeekly04","_rev":"2-db3196bca095e863bfb15018b4ac0367","source":"https://04ed5b38-f595-44e9-b875-031ed3423e71-bluemix:3d4cda975fbdc54cc441020f0fe5d52b6daed60ff7c9fd0aba2075fe85927168@04ed5b38-f595-44e9-b875-031ed3423e71-bluemix.cloudant.com/promotions","target":"https://427af75d-df61-496c-9a54-2c66ff87858d-bluemix:a8257e322fe0bfd6d95f97e7d83543489e03c50dcc2dd08952bd3625403e2b25@427af75d-df61-496c-9a54-2c66ff87858d-bluemix.cloudant.com/promotions","create_target":true,"continuous":true,"_replication_state":"triggered","_replication_state_time":"2016-11-01T16:54:59+00:00","_replication_id":"2d967c44f967e505161df04f983d39da"}
```

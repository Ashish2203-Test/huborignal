# sagan-logging
> Logging library for WA

## Installation

1. Copy logging library under your project under "sagan-logging" folder
2. Add a dependency in package.json
```
"sagan-logging": "file:./sagan-logging",
```

## Fields

The library provides following methods
 info()
 debug()
 error()
 silly()
 warn()
 
Each method supports below parameters
- methodName: Method name [Optional]
- clientId: Client identifier [Optional]
- requestId: Unique request id [Optional]
- userId: User identifier [Optional]
- message: Your log data
- custom: Any other custom attributes in JSON format [Optional]
- forCustomer: true if this log record is to be sent to customer's Bluemix account logging instance

## Supported env

The library supports below env
- production-dev
- production-test
- production-staging
- production
- staging [Bluemix staging]

The env name is to be passed as a parameter for init() method of lib
 
## Usage

```js
const logger = require('sagan-logging');
logger.init(env);

logger.info('methodName', 'clientId', 'requestId', 'userId', 'my messsage', {}, true)
logger.error('methodName', 'clientId', 'requestId', 'userId', 'Some critical error', {}, false)
logger.debug('methodName', null, 'requestId', null, 'Checking values...', { 'key': 'value' }, false)
```

/**
 * Created by deanh on 27/08/2017.
 */

var bl = require('sagan-dev-node-sdk').bl;
var counter = 0;

const AVATAR = "/avatar";
const EXPERTISE = "/expertise";
const REGISTRY = "/registry";
const LINK = "/link";
const CLIENT_KEY = "clientGuid";
//
// bl.route.getAll(function (err, cores) {
//     cores.forEach(function (core) {
//         var persistency = core.persistentData;
//         if (persistency) {
//             var clientID = core[CLIENT_KEY];
//             var avatars = persistency[AVATAR];
//             var expertises = persistency[EXPERTISE];
//             var registries = persistency[REGISTRY];
//             var links = persistency[LINK];
//
//             if (avatars) {
//                 avatars.forEach(function (avatar) {
//                     bl.configuration.insertClientAvatar(clientID, avatar, function (err, result) {
//                         if (!err) {
//                             counter++;
//                             console.log(counter);
//                         }
//                     })
//                 });
//             }
//
//             if (expertises) {
//                 expertises.forEach(function (expertise) {
//                     bl.configuration.insertClientExpertise(clientID, expertise, function (result) {
//                         if (!err) {
//                             counter++;
//                             console.log(counter);
//                         }
//                     })
//                 });
//             }
//
//             if (registries) {
//                 registries.forEach(function (expertise) {
//                     bl.configuration.insertClientRegistry(clientID, expertise, function (result) {
//                         if (!err) {
//                             counter++;
//                             console.log(counter);
//                         }
//                     })
//                 });
//             }
//
//             if (links) {
//                 links.forEach(function (link) {
//                     bl.configuration.insertClientLink(clientID, link, function (result) {
//                         if (!err) {
//                             counter++;
//                             console.log(counter);
//                         }
//                     })
//                 });
//             }
//         }
//     });
// });

bl.route.getAll(function (err, cores) {
    cores.forEach(function (core) {
        core.persistentData = undefined;
        delete core.persistentData;
        core.clientID = core[CLIENT_KEY];
        core[CLIENT_KEY] = undefined;
        delete core[CLIENT_KEY];

        bl.route.update(core, function(err, result) {
            if (!err) {
                counter++;
                console.log(counter);
            }
        })
    });
});
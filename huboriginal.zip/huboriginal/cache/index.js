const type = process.env.CACHE_TYPE || 'redis';
console.log('cache/index, Configured cache type: ', type);

module.exports = require(`./${type}`);

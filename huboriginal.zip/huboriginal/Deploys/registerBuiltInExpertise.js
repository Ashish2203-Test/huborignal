const https = require('https');
const process = require('process');
const expertiseConstants = require('./registerExpertise');

const apiKey = process.argv[2];
const spaceName = process.argv[3];

const hostnames = {
    'dev': 'dev-sagan-hub.mybluemix.net',
    'test': 'test-sagan-hub.mybluemix.net',
    'prod' : 'personal-assistant-toolkit.mybluemix.net'
};

let bindExpertise = function(expertiseName) {
    return JSON.stringify(
        {
            'fallback': false,
            'skillNames': [
                expertiseName
            ]
        });
};

let createRequest = function(object, parameter) {
    return {
        'object': object,
        'parameter': parameter
    }
};

let requestOptions = function(path, method) {
    return {
        hostname: hostnames[spaceName],
        method: method,
        path: path,
        headers: {
            'api_key': apiKey,
            'Content-Type': 'application/json',
            'Accept': 'text/xml',
        }
    }
};

const handleResponse = function(res) {
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
        console.log(`BODY: ${chunk}`);
    });
    res.on('end', () => {
        callNextRequest();
    });
};

const handleError = function(e) {
    console.error(`problem with request: ${e.message}`);
};

//create all expertise registry requests and bind requests
let registerAllExpertiseForCollection = function(collectionName) {
    for (let expertiseName in expertiseConstants.collections[collectionName].expertise) {
        //create registry request
        let registerExpertiseOptions = requestOptions('/v2/api/skills/', 'POST');
        let registerExpertiseRequest = https.request(registerExpertiseOptions, handleResponse);
        registerExpertiseRequest.on('error', handleError);
        let expertiseJSON = JSON.stringify({
            'name': expertiseName,
            'url': expertiseConstants.collections[collectionName].expertise[expertiseName].url
        });
        let registerRequest = createRequest(registerExpertiseRequest, expertiseJSON);
        requests.push(registerRequest);

        // create bind request
        let bindExpertiseOptions = requestOptions('/v2/api/skillSets/' + collectionName, 'PUT');
        let bindExpertiseRequest = https.request(bindExpertiseOptions, handleResponse);
        bindExpertiseRequest.on('error', handleError);
        let bindRequest = createRequest(bindExpertiseRequest, bindExpertise(expertiseName));
        requests.push(bindRequest);
    }
};

let requests = [];
// create all collections creation requests
for(let collectionName in expertiseConstants.collections) {
    let createCollectionOptions = requestOptions('/v2/api/skillSets/', 'POST');
    let createCollectionRequest = https.request(createCollectionOptions, handleResponse);
    createCollectionRequest.on('error', handleError);
    let request = createRequest(createCollectionRequest, JSON.stringify({ "name": collectionName }));
    requests.push(request);
    registerAllExpertiseForCollection(collectionName);
}

let requestIndex = 0;
let callNextRequest = function() {
    if(requestIndex < requests.length) {
        let request = requests[requestIndex].object;
        let parameter = requests[requestIndex].parameter;
        requestIndex++;
        request.write(parameter);
        request.end();
    }
    else {
        console.log('Finished creating built-in skills');
    }
};
callNextRequest();

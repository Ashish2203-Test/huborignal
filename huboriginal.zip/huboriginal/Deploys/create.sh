#!/bin/bash


echo "Please login to the target space (sagan-hub must be present in that space)"
#cf login

echo "Please enter the client's name:"
read client;
space=$(cf t | sed -e '$!d' | awk '{print $NF}')
org=$(cf t | sed '$d' | sed '$!d' | awk '{print $NF}')

echo "Creating new core for '$client' in organization '$org' in space '$space'. continue? (y/n)"
read continue;

if [[ $continue = 'y' ]] ; then
    params=$(WF_DEPLOY_DIRECT_TARGET_PREFIX=sagan-hub CLIENT_NAME=$client node createNewCore.js);

    IFS=' ' read -ra paramsArray <<< "$params"

    corename=${paramsArray[0]}
    apikey=${paramsArray[1]}

    if [[ $corename = 'ERROR' ]] ; then
        echo "${paramsArray[*]}"
    else
        mkdir ../../SaganCore/Deploys/$org/
        mkdir ../../SaganCore/Deploys/$org/$space
        echo "creating push file - push.$space.$corename.sh"
        sed 's/{corename}/'"$corename"'/g;s/{space}/'"$space"'/g;s/{org}/'"$org"'/g' saganCore.template.sh > ../../SaganCore/Deploys/$org/$space/push.$space.$corename.sh
        chmod 777 ../../SaganCore/Deploys/$org/$space/push.$space.$corename.sh
        echo "creating yml file - $space.$corename.yml"
        sed 's/{corename}/'"$corename"'/g' saganCore.template.yml > ../../SaganCore/Deploys/$org/$space/$space.$corename.yml
        echo "pushing core to bluemix"
        (cd ../../SaganCore/Deploys/$org/$space; ./push.$space.$corename.sh)

        echo "deploying K&R"
        # Create the right commands
        if [ ! -d "../../sagan-knowledge-query/onboarding_project/auto_onboard__" ]; then
            python3_path=$(which python3 | sed /aliased/d | head -n1 | cut -d" " -f 3)
            create_env_cmd="virtualenv auto_onboard__ --python=$python3_path"
            pip_install_cmd="pip install -r requirements-onboarding.txt"
        fi
        (
            cd ../../sagan-knowledge-query/onboarding_project/
            $create_env_cmd
            source auto_onboard__/bin/activate
            $pip_install_cmd
            python deploy_kr_cli.py $space --onboard ${paramsArray[1]}
        )

        echo "Creating built-in expertise"

        node registerBuiltInExpertise.js ${apikey} ${space}

        echo "client: ${client}"
        echo "API_KEY: ${apikey}"
    fi
else
    echo "Exiting..."
fi


/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var https = require('https');
var method = "POST";
var baseHost = "github.ibm.com";
var baseAPI = "/api/v3";
var coreRepo = "/repos/ConsumerIoT/SaganCore";
var ExpertiseBoilerPlateRemoteRepo = "/repos/ConsumerIoT/ExpertiseBoilerPlateRemote";
var SaganHubRepo = "/repos/ConsumerIoT/SaganHub";
var KnowledgeAndReasoning = "/repos/ConsumerIoT/KnowledgeAndReasoning";
var saganMessageBroker = "/repos/ConsumerIoT/sagan-message-broker";
var saganKnowledgeQuery = "/repos/ConsumerIoT/sagan-knowledge-query";



var milestones = "/milestones";

var username = "deanh";
var token = "f9fd8b3c023c3334577c437ee3558a39363bdf3a"; // Dean's personal token
var auth = 'Basic ' + new Buffer(username + ':' + token).toString('base64');

var headers = {
    authorization: auth
};

var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

var getDate = function (year, month, day) {
    return (new Date(monthNames[month - 1] + " " + day + ", " + year + " 23:59:59"));
};

function addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

var getDateString = function (date) {
    var year = date.getFullYear();
    var tempMonth = date.getMonth() + 1;
    var month = tempMonth < 10 ? "0" + tempMonth : tempMonth;
    var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();

    return (year + "." + month + "." + day);
};

var gitPost = function (repo, action, body) {
    var req = https.request({
        host: baseHost,
        path: baseAPI + repo + action,
        headers: headers,
        method: method
    }, function (res) {

        var output = '';
        console.log('statusCode :' + res.statusCode);
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            output += chunk;
        });

        res.on('end', function () {
            var obj = JSON.parse(output);
            console.log(obj);
        });
    });

    req.write(body);
    req.end();
};

var getSprintJSON = function (sprintNumber, endDate) {
    var startDate = addDays(endDate, -13);
    var title = "Sprint " + sprintNumber + " - " + getDateString(startDate);
    var body = JSON.stringify({
        "title": title,
        "state": "open",
        "description": "",
        "due_on": endDate.toISOString()
    });

    return body;
};

/*
 This will create new sprints as milestones.
 numberOfSprintsToCreate - how many sprints to create
 sprintNumber - number of the first sprint (could be 6/13/26/etc...)
 endDate - of that first sprint
 */

var repos = [
    // coreRepo,
    // ExpertiseBoilerPlateRemoteRepo,
    // SaganHubRepo,
    // KnowledgeAndReasoning,
    saganMessageBroker,
    saganKnowledgeQuery
];

var createSprints = function (sprintNumber, endDate, numberOfSprintsToCreate) {
    var currDate = new Date(endDate);

    for (var index = 0; index < numberOfSprintsToCreate; index++) {

        var json = getSprintJSON(sprintNumber + index, currDate);

        repos.forEach(function (repo) {
            gitPost(repo, milestones, json);
        });

        currDate = addDays(currDate, 14);
    }
};

createSprints(6, getDate(2017, 7, 13), 13);


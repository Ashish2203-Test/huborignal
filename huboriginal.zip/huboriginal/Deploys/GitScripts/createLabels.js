/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var https = require('https');
var method = "POST";
var baseHost = "github.ibm.com";
var baseAPI = "/api/v3";

var coreRepo = "/repos/ConsumerIoT/SaganCore";
var ExpertiseBoilerPlateRemoteRepo = "/repos/ConsumerIoT/ExpertiseBoilerPlateRemote";
var SaganHubRepo = "/repos/ConsumerIoT/SaganHub";
var KnowledgeAndReasoning = "/repos/ConsumerIoT/KnowledgeAndReasoning";
var saganMessageBroker = "/repos/ConsumerIoT/sagan-message-broker";
var saganKnowledgeQuery = "/repos/ConsumerIoT/sagan-knowledge-query";

var labels = "/labels";

var username = "deanh";
var token = "f9fd8b3c023c3334577c437ee3558a39363bdf3a"; // Dean's personal token
var auth = 'Basic ' + new Buffer(username + ':' + token).toString('base64');

var headers = {
    authorization: auth
};

var gitReq = function (method, repo, action, body, callback) {
    console.log("baseAPI + repo + action: " + (baseAPI + repo + action));
    var req = https.request({
        host: baseHost,
        path: baseAPI + repo + action,
        headers: headers,
        method: method
    }, function (res) {

        var output = '';
        console.log('statusCode :' + res.statusCode);
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            output += chunk;
        });

        res.on('end', function () {
            try {
                var obj = JSON.parse(output);
            } catch (e) {
                console.log("out: " + output);
                var obj = JSON.parse(output);
            }
            callback(obj);
        });
    });

    if (body) {
        req.write(body);
    }

    req.end();
};

/*
 This will create new sprints as milestones.
 numberOfSprintsToCreate - how many sprints to create
 sprintNumber - number of the first sprint (could be 6/13/26/etc...)
 endDate - of that first sprint
 */

var repos = [
    // coreRepo,
    ExpertiseBoilerPlateRemoteRepo,
    SaganHubRepo,
    KnowledgeAndReasoning,
    saganMessageBroker,
    saganKnowledgeQuery
];

var createLabel = function (repo, name, color) {
    var json = {"name": name, "color": color};

    gitReq("POST", repo, labels, JSON.stringify(json), function (result) {
        console.log(result);
    });
};

var getAllLabels = function (repo, callback) {
    gitReq("GET", repo, labels, undefined, callback);
};

var copyLabelsFromCoreRepo = function (targetRepo, callback) {
    getAllLabels(coreRepo, function (list) {
        list.forEach(function (label) {
            createLabel(targetRepo, label.name, label.color);
        });
    });
};

var deleteAllLabels = function (repo, callback) {
    getAllLabels(repo, function (list) {
        list.forEach(function (label) {
            // console.log("label: " + label.name);
            gitReq("DELETE", repo, labels + "/" + label.name.replace(" ", "%20"), undefined, function (result) {
                console.log("deleted: " + label.name);
            });
        });
    });
};

let newLabelName = "Content Team";
let newLabelColor = "0e8a16";

let createLabelForRepos = function () {
    repos.forEach(function(repo) {
       createLabel(repo, newLabelName, newLabelColor);
    });
};

// createLabelForRepos();
// deleteAllLabels(saganKnowledgeQuery);
// copyLabelsFromCoreRepo(saganKnowledgeQuery);


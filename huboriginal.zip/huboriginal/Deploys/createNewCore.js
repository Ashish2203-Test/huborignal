/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

// overcoming framework gap
var process = require('process');
process.chdir('../');
process.argv[1] = process.cwd() + "/d";

var tempLog = console.log;

// Shutting console.log
console.log = function () {
};

var bl = require("sagan-dev-node-sdk").bl;

// resetting console.log
console.log = tempLog;

bl.route.addNewRoute(process.env.CLIENT_NAME, function (err, result) {
    if (err) {
        console.log("err: " + err);
    } else {
        console.log(result.coreUrl.split('.')[0] + " " + result.apikey);
    }
});
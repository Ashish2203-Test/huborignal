cf target -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f sagan.prod.saganHub.yml
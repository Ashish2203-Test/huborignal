cf target -s test
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f sagan.test.saganHub.yml
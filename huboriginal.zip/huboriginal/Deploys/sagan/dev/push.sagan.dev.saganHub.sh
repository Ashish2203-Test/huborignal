cf target -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f sagan.dev.saganHub.yml
cf target -o {org} -s {space}
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f {space}.{corename}.yml

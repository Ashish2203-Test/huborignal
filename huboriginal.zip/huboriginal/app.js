/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

var app = require('express')();
var addRequestId = require('express-request-id')();

app.use(addRequestId);

app.get('/', function (req, res, next) {
    res.send(req.id);
    next();
});

app.listen(3005, function () {
});

var request = require('request');

request('http://localhost:3005/', function (error, response, body) {
    global.requestid = body;
});

const logger = require('./sagan-logging/logger');
logger.init("production");
let as_enabled = process.env.ENABLE_AUTOSCALE;
if (as_enabled !== undefined && as_enabled.toLowerCase() === 'true') {
    let agent = require('bluemix-autoscaling-agent');
    //console.log('Bluemix autoscaling is ENABLED');
    logger.info('as_enabled', global.clientId, global.requestid, null, 'Bluemix autoscaling is ENABLED', {}, false)
} else {
    //console.log('Bluemix autoscaling is DISABLED');
    logger.error('as_disabled', global.clientId, global.requestid, null, 'Bluemix autoscaling is DISABLED', {}, false)
}

if (!global.clientId) {
    global.clientId = null;
}
let wfapi = require("sagan-dev-node-sdk").api;
let bl = require("sagan-dev-node-sdk").bl;
let express = require("express");
let session = require('express-session');
let path = require('path');
let https = require('https');
let url = require('url');
let querystring = require('querystring');
let exec = require('child_process').exec;
let activity = require('./addons/activity/activity');
let authRequest = require('./addons/iam/auth-request');
let cookieParser = require('cookie-parser');

const AGENT_BROKER_ROUTE_EXPR = "/agent/";
const KNOWLEDGE_QUERY_ROUTE_EXPR = "/knowledge/";
const CONTEXT_QUERY_ROUTE_EXPR = "/context/";

const DOCS_URL = "/docs/";
const API_DOCS = "/api-docs";
const API_KEY = "api_key";
const DUMMY_API_DOCS = require('./dummy-api-docs.json');

wfapi.app.enable('trust proxy');
wfapi.app.use(cookieParser());

// --- This is good for development and debugging ---
// wfapi.app.use(session({secret: "Shh, its a secret!"}));

// Use redis as session store for production
let redis = require("redis");
let RedisStore = require('connect-redis')(session);

let creds = require("sagan-dev-node-sdk").credentials;
let credentials = creds.getCredentialsByServiceName('compose-for-redis');
let redisClient = redis.createClient(credentials.uri);

wfapi.app.use(session({
    store: new RedisStore({ client: redisClient }),
    resave: 'true',
    saveUninitialized: 'true',
    secret: 'p@rsERsta!emeNt'
}));

// wfapi.app.use("/", express.static(""));

// Redirecting to https://......
wfapi.app.use(function (req, res, next) {
    if (req.secure || process.env.WF_DEPLOY_TARGET === "local") {
        // request was via https, so do no special handling
        next();
    } else if (!req.url.startsWith('/v1')) {
        // request was via http, so redirect to https
        res.redirect('https://' + req.headers.host + req.url);
    }
});

// When this is first - no auth is required
wfapi.app.use('/', express.static('./addons/pages/', { index: "landingPage/landingPage.html" }));
wfapi.app.use("/angular", express.static('./node_modules/angular/'));
wfapi.app.use("/jquery", express.static('./node_modules/jquery/'));

wfapi.app.get('/iam-login', function (req, res) {
    // console.log('Start /iam-login');
    logger.info('iam-login', global.clientId, global.requestid, null, 'Start /iam-login', {}, false)
    authRequest.login(req, res);
});

wfapi.app.get('/auth-callback', function (req, res) {
    authRequest.authCallback(req, res);
});

wfapi.app.get('/config', function (req, res) {
    res.send({ iamEnabled: process.env.ENABLE_IAM });
});

wfapi.app.get('/validateKey/:apikey', function (req, res) {
    let apikey = req.params.apikey;

    bl.route.validateKey(apikey, function (core) {
        if (core) {
            res.sendStatus(200);
        } else {
            res.sendStatus(401);
        }
    });
});

// wfapi.app.get(API_DOCS, function (req, res) {
//     res.end(JSON.stringify(DUMMY_API_DOCS));
// });
//

// From this point forward - all endpoints will be verified with api key
wfapi.app.all('*', function (req, res, next) {
    if (getKey(req)) {
        handleAPI(req, res, function () {
        });
    } else {
        // console.log('Calling authRequest.isAuthorized');
        logger.info('authRequest', global.clientId, global.requestid, null, 'Calling authRequest.isAuthorized', {}, false)
        authRequest.isAuthorized(req, function (err, core) {
            if (err || !core) {
                console.error(err);
                res.status(401);
                res.send(err);
            } else {
                // console.log('Request authorized. calling handleAPI');
                logger.info('AshNode', global.clientId, global.requestid, null, 'Request authorized. calling handleAPI', {}, false)
                handleAPIUsingIAM(req, res, core, function () {
                });
            }
        });
    }
});

let getContextURL = function () {
    let url;
    if (process.env.CONTEXT_SERVICE_URL) {
        url = process.env.CONTEXT_SERVICE_URL;
    } else {
        let spaceName;
        if (process && process.env && process.env.VCAP_APPLICATION) {
            spaceName = JSON.parse(process.env.VCAP_APPLICATION).space_name;
        } else if (process.env.SPACE_NAME) {
            spaceName = process.env.SPACE_NAME;
        }
        url = `${spaceName}-sagan-context.mybluemix.net`;
    }
    return url;
};

let getKey = function (req) {
    let key = req.headers[API_KEY] || req.query[API_KEY];

    if (!key) {
        let query;

        let referer = req.headers.referer;
        if (referer) {
            let parsedUrl = url.parse(req.headers.referer);
            query = querystring.parse(parsedUrl.query);
        } else {
            query = req.query;
        }

        key = query[API_KEY];
    }

    return (key);
};

let handleAPI = function (req, res, callback) {
    let key = getKey(req);

    if (!key && req.url.startsWith(API_DOCS)) { // Swagger verification
        res.end(JSON.stringify(DUMMY_API_DOCS));
    } else {
        bl.route.validateKey(key, function (core) {
            if (!core) {
                res.sendStatus(401);
            } else {
                global.clientId = core.clientID;
                let headers = {
                    "content-type": "application/json",
                    "space-key": spaceGuid,
                    "clientID": core.clientID
                };

                let nextUrl = getServiceUrl(core, req);
                //  console.log('next url is: ' + nextUrl);
                //  logger.info('AshNode', null, global.requestid,'next url is: ' + nextUrl , 'Knowledge returning 401', {}, false)

                if (!nextUrl) {
                    // console.log('Knowledge returning 401');
                    logger.error('handleAPI', global.clientId, global.requestid, null, 'Knowledge returning 401', {}, false)
                    activity.insertApiActivityRecordForApiKey(key, nextUrl, 401);
                    res.sendStatus(401, 'Unauthorized\nPlease contact your local IBM Watson Personal Assistant dealer to enable this feature\n')
                } else {
                    let options = {
                        host: nextUrl,
                        path: req.url,
                        method: req.method,
                        // port: 10010,
                        headers: headers
                    };

                    let connector = https.request(options, function (resp) {
                        res.statusCode = resp.statusCode;
                        activity.insertApiActivityRecordForApiKey(key, nextUrl + req.url, resp.statusCode);

                        let keys = Object.keys(resp.headers);
                        keys.forEach(function (key) {
                            res.setHeader(key, resp.headers[key]);
                        });

                        resp.pipe(res);
                        callback();
                    });

                    if (req.body) {
                        connector.write(JSON.stringify(req.body));
                    }

                    req.pipe(connector);
                }
            }
        });
    }
};

/**
 * Handle auth and authz using Bluemix IAM api key
 * @param req
 * @param res
 * @param core
 * @param callback
 */
let handleAPIUsingIAM = function (req, res, core, callback) {
    if (req.url.startsWith(API_DOCS)) {
        res.end(JSON.stringify(DUMMY_API_DOCS));
    } else {
        global.clientId = core.clientID;
        let headers = {
            "content-type": "application/json",
            "space-key": spaceGuid,
            "clientID": core.clientID
        };

        let nextUrl = getServiceUrl(core, req);
        //  console.log('next url is: ' + nextUrl);
        //  logger.info('AshNode', null, 'requestId', 'next url is: ' + nextUrl, 'Knowledge returning 401', {}, false)

        if (!nextUrl) {
            //  console.log('Knowledge returning 401');
            logger.error('handleAPIUsingIAM', global.clientId, global.requestid, null, 'Knowledge returning 401', {}, false)
            activity.insertApiActivityRecordForIAM(core, nextUrl, 401);
            res.sendStatus(401, 'Unauthorized\nPlease contact your local IBM Watson Personal Assistant dealer to enable this feature\n');
        } else {
            let options = {
                host: nextUrl,
                path: req.url,
                method: req.method,
                headers: headers
            };

            let connector = https.request(options, function (resp) {
                res.statusCode = resp.statusCode;
                activity.insertApiActivityRecordForIAM(core, nextUrl + req.url, resp.statusCode);

                let keys = Object.keys(resp.headers);
                keys.forEach(function (key) {
                    res.setHeader(key, resp.headers[key]);
                });

                resp.pipe(res);
                callback();
            });

            if (req.body) {
                connector.write(JSON.stringify(req.body));
            }

            req.pipe(connector);
        }
    }
};

let URL = require('url');

let getServiceUrl = function (route, req) {
    let url = req.headers.referer || req.url;
    let path = URL.parse(url).path;

    // console.log('the path is: ' + path);
    // logger.info('AshNode', null, global.requestid, null, 'the path is: ' + path, {}, false)
    let nextUrl;

    if (path.indexOf(AGENT_BROKER_ROUTE_EXPR) === 0) {
        nextUrl = route.agentBrokerUrl;
    } else if (path.indexOf(KNOWLEDGE_QUERY_ROUTE_EXPR) === 0) {
        nextUrl = route.knowledgeQueryUrl;
    } else if (path.indexOf(CONTEXT_QUERY_ROUTE_EXPR) === 0) {
        nextUrl = getContextURL();
    } else {
        nextUrl = route.coreUrl;
    }

    return nextUrl;
};

let getSpaceGuid = function (callback) {
    if (process && process.env && process.env.VCAP_APPLICATION) {
        let guid = JSON.parse(process.env.VCAP_APPLICATION).space_id;
        callback(guid);
    } else if (process.env.WF_DEPLOY_TARGET !== "local") {
        exec("cf env " + process.env.WF_DEPLOY_DIRECT_TARGET_PREFIX, function (error, stdout, stderr) {
            if (error) {

                callback("");
            } else {
                let indexSpaceID = stdout.indexOf("space_id");
                let guid = stdout.substr(indexSpaceID + 12, 36);
                // console.log(guid);
                logger.info('getSpaceGuid', global.clientId, global.requestid, 'userId', guid, {}, false)
                callback(guid);
            }
        });
    } else {
        callback("");
    }
};

let spaceGuid;
getSpaceGuid(function (guid) {
    spaceGuid = guid;
    wfapi.startServer();
});
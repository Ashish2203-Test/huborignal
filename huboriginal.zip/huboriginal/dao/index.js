const type = process.env.DB_TYPE || 'dashdb';
console.log('dao/index, Configured db type: ', type);

module.exports = require(`./${type}`);

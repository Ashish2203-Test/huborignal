var ibmdb = require('ibm_db');
require('cf-deployment-tracker-client').track();

let credentials = require("sagan-dev-node-sdk").credentials;
let dashdb = credentials.getCredentialsByServiceName('dashDB For Transactions');
console.log('dashdb credentials:', dashdb);

let connection = null;
if (dashdb) {
    const connString = "DRIVER={DB2};DATABASE=" + dashdb.db + ";UID=" + dashdb.username + ";PWD=" + dashdb.password + ";HOSTNAME=" + dashdb.hostname + ";port=" + dashdb.port;
    ibmdb.open(connString, function (err, conn) {
        if (err) {
            console.error("Error occurred while connecting to dashdb" + err.message);
        }
        else {
            connection = conn;
            console.log('Successfully connected to dashdb');
        }
    });
}

function execute(query) {
    if (connection) {
        console.log('dao/dashdb, Executing query: ', query);
        return new Promise((resolve, reject) => {
            connection.query(query, function(err, tables, moreResultSets) {
                if (!err) {
                    resolve(tables);
                } else {
                    console.error("Error occurred while executing query: ", err.message);
                    return reject("Error occurred while executing query: ", err.message);
                }
            });
        })
    } else {
        console.error('*** Sagan dashdb information NOT available ***');
        return Promise.reject('Sagan dashdb information NOT available');
    }
}

/**
 * Insert record into table
 * @param query - Used to prepare statement
 * @param params - Array for parameter substitution
 * @returns {boolean}
 */
function insert(query, params) {
    if (connection) {
        return new Promise((resolve, reject) => {
            connection.prepare(query, function (err, stmt) {
                if (err) {
                    console.error('dao/dashdb, insert, Error while preparing statement: ', err);
                    resolve();
                } else {
                    stmt.execute(params, function (err, result) {
                        if (err) {
                            console.error('dao/dashdb, insert, Error while inserting record: ', err);
                            return reject('dao/dashdb, insert, Error while inserting record: ', err);
                        } else {
                            resolve(result);
                        }
                    })
                }
            })
        })
    } else {
        console.error('*** Sagan dashdb information NOT available ***');
        return Promise.reject('Sagan dashdb information NOT available');
    }
}

module.exports = {
    execute: execute,
    insert: insert
};
